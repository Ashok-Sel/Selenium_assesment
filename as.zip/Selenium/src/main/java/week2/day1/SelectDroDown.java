package week2.day1;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDroDown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		String title = driver.getTitle();
System.out.println(title);

driver.findElementByName("USERNAME").sendKeys("DemoSalesManager");
driver.findElementById("password").sendKeys("crmsfa");
driver.findElementByClassName("decorativeSubmit").click();
driver.findElementByLinkText("CRM/SFA").click();

driver.findElementByLinkText("Leads").click();
driver.findElementByLinkText("Create Lead").click();
driver.findElementById("createLeadForm_companyName").sendKeys("ashok");
driver.findElementById("createLeadForm_lastName").sendKeys("ss");
driver.findElementById("createLeadForm_firstName").sendKeys("gd");
WebElement findElementById = driver.findElementById("createLeadForm_dataSourceId");

//Select ele = new Select(findElementById);
//ele.selectByVisibleText("Partner");

//WebElement findElementByXPath = driver.findElementByXPath("//select[@id='createLeadForm_dataSourceId']//..//option");

//Select ele1 = new Select(findElementByXPath);

//ele1.selectByVisibleText("Cold Call");
//ele1.selectByVisibleText("Direct Mail");

List<WebElement> findElementsByXPath = driver.findElementsByXPath("//select[@id='createLeadForm_industryEnumId']//..//option");
int size =findElementsByXPath.size();
System.out.println(findElementsByXPath.size());

for (int i = 0; i < size; i++)

{
		String text = findElementsByXPath.get(i).getText();
		if(text.startsWith("P"))
			
		System.out.println(text);
	}
}

//driver.findElementByClassName("smallSubmit").click();


//driver.close();

	/*driver.findElementByXPath("//input[@name='USERNAME']").sendKeys("DemoCSR");
	driver.findElementByXPath("//input[@name='PASSWORD']").sendKeys("crmsfa");;
	driver.findElementByXPath("//input[@type='submit']").click();
	driver.findElementByXPath("//a[contains(text(),'CRM/SFA')]").click();
	driver.findElementByXPath("//a[contains(text(),'Leads')]").click();
	driver.findElementByXPath("//a[contains(text(),'Find Leads')]").click();
	driver.findElementByXPath("(//input[@name='firstName'])[3]").sendKeys("ashok");
	driver.findElementByXPath("//button[text()='Find Leads']").click();
	Thread.sleep(3000);
	driver.findElementByXPath("//a[text()='10388']").click();
	System.out.println(driver.findElementByXPath("//span[text()='ashok']").getText().equals("ashok"));
	driver.close();
	
	//span[text()='ashok']
	
	
	*/
	
	
	
	
	

	

}
