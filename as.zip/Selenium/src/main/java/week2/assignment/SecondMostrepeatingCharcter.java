package week2.assignment;

public class SecondMostrepeatingCharcter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s = "financial".trim().replace(" ", "");
char[] ch1=s.toCharArray();
int length = s.length();
int a=0;
int b =0;
char sp = 0;
char ds=0;

for(int i=0;i<length;i++)
{
	int count=0;
	for(int j=0;j<length;j++)
	{
		if(ch1[i]==ch1[j])
		{
			count++;
		}
		
		if(count>a)
		{
			a=count;
			 sp=ch1[i];
			 
		}
	
	}
}


String v =Character.toString(sp);

String d =s.replace(v, "");
char[] e=d.toCharArray();
int length2 =d.length();
for(int x=0;x<length2;x++)
{
	
	int count=0;
for(int y=0;y<length2;y++)
	{
		if(e[x]==e[y])
		{
			count++;
		}
		
		if(count>b)
		{
			b=count;
			 ds=e[x];
			
			 
		}
	
	}
}
System.out.println("Second Most Repeating Character - " +ds);



	}

}
