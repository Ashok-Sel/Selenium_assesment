package week2.assignment;

public class DuplicateCharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stubs
		String s="infosys limited".trim().replace(" ", "");
		char[] ch=s.toCharArray();
		int length = s.length();
		String duplicateString="";
		String  k="";
		for(int i=0;i<length;i++)
		{
			int count=0;
			for(int j=0;j<length;j++)
			{
				if(ch[i]==ch[j])
				{
					count++;
				}
			}
					
					if(count>1)
					{
					duplicateString = Character.toString(ch[i]);
					if(!k.contains(duplicateString))
					{
					k=k.concat(duplicateString);
					
				    }
					}
			    
		   

	 }
		System.out.println(k);
		

}
	
}
