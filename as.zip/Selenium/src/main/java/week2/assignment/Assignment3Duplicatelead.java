package week2.assignment;

import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment3Duplicatelead {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leaftaps.com/opentaps/control/main");
		driver.findElementByXPath("//input[@name='USERNAME']").sendKeys("DemoCSR");
		driver.findElementByXPath("//input[@name='PASSWORD']").sendKeys("crmsfa");;
		driver.findElementByXPath("//input[@type='submit']").click();
		driver.findElementByXPath("//a[contains(text(),'CRM/SFA')]").click();
		driver.findElementByXPath("//a[contains(text(),'Leads')]").click();
		driver.findElementByXPath("//a[contains(text(),'Find Leads')]").click();
		driver.findElementByXPath("//span[text()='Email']").click();
		driver.findElementByXPath("//input[@name='emailAddress']").sendKeys("ashok@gmail.com");
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(3000);
		String firstName= driver.findElementByXPath("(//div/a)[42]").getText();
		String lastName = driver.findElementByXPath("(//div/a)[43]").getText();
		driver.findElementByXPath("(//div/a)[42]").click();
		driver.findElementByXPath("//a[text()='Duplicate Lead']").click();
		boolean title=driver.findElementByXPath("//div[text()='Duplicate Lead']").getText().contains("Duplicate Lead");
		System.out.println(title);
		driver.findElementByXPath("//input[@value='Create Lead']").click();
		if(driver.findElementByXPath("(//span[text()='First name']/following::span)[1]").getText().equals(firstName))
		{
			System.out.println("First name equals");
		}
		
		else
		{
			System.out.println("First name mismatches");
		}
		
		if(driver.findElementByXPath("(//span[text()='Last name']/following::span)[1]").getText().equals(lastName))
		{
			System.out.println("Last name equals");
		}
		else
		{
			System.out.println("last name mismatches");
			
		}
		
		driver.close();
	
	}
	

}
