package week2.assignment;

public class StringBufferReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StringBuffer txt=new StringBuffer("Test Automation");
System.out.println(txt.reverse());
	}

}
