package week2.assignment;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropdownLeafGround {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/pages/Dropdown.html");
		
		WebElement Dropdown1=driver.findElementById("dropdown1");
		Select Dp1 = new  Select(Dropdown1);
		Dp1.selectByIndex(1);
		
		WebElement Dropdown2=driver.findElementByName("dropdown2");
		Select Dp2 = new  Select(Dropdown2);
		Dp2.selectByVisibleText("Selenium");
		
		WebElement Dropdown3=driver.findElementById("dropdown3");
		Select Dp3 = new  Select(Dropdown3);
		Dp3.selectByValue("1");
		
		WebElement Dropdown4=driver.findElementByXPath("//select[@class='dropdown']");
		Select Dp4 = new  Select(Dropdown4);
		List<WebElement> options = Dp4.getOptions();
		System.out.println(options.size());
		
		WebElement Dropdown5 = driver.findElementByXPath("(//div[@class='example']/select)[5]");
		Select Dp5 = new Select(Dropdown5);
		Dropdown5.sendKeys("Selenium");
		
		WebElement Dropdown6 = driver.findElementByXPath("//*[@id=\"contentblock\"]/section/div[6]/select");	 
		System.out.println("comindfd");
		Select Dp6= new Select(Dropdown6);
		List<WebElement> options2 = Dp6.getOptions();
		int size = options2.size();
		
		for(WebElement ele:options2)
		{
			if(ele.getText().endsWith("m"))
					{
				ele.click();
					}
		}
		
		

		
		
		

		
		

	}

}
