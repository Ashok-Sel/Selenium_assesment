package week2.assignment;

public class ReverseAString {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
String txt="Write Some String Programs Today".trim().replace(" ", "");
int length =txt.length();
String a="";

for(int i=length-1;i>=0;i--)
{
	a=a+(txt.charAt(i));
}
System.out.println(a);
	}

}
