package week2.assignment;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropdownByXpath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
ChromeDriver driver = new ChromeDriver();
driver.navigate().to("http://leaftaps.com/opentaps/control/login");
driver.findElementByXPath("//label[@for='username']/following-sibling::input").sendKeys("DemoCSR");
driver.findElementByXPath("//label[@for='password']/following-sibling::input").sendKeys("crmsfa");
driver.findElementByXPath("//input[@type='submit']").click();
driver.findElementByXPath("//div[@for='crmsfa']/a").click();
driver.findElementByXPath("(//a)[9]").click();
driver.findElementByXPath("(//a)[28]/preceding::a[1]").click();
driver.findElementByXPath("//span[text()='Company Name']/following::input[1]").sendKeys("Test");
driver.findElementByXPath("//span[text()='First name']/following::input[1]").sendKeys("Ashok");
driver.findElementByXPath("//span[text()='Last name']/following::input[1]").sendKeys("s");

WebElement findElementByXPath = driver.findElementByXPath("(//span[text()='Ownership']/following::select)[1]");
Select Ownership =new Select(findElementByXPath);
Ownership.selectByVisibleText("Public Corporation");

WebElement findElementByXPath1 = driver.findElementByXPath("(//span[text()='Marketing Campaign']/following::select)[1]");
Select Ownership1 =new Select(findElementByXPath1);
Ownership1.selectByVisibleText("Affiliate Sites");

driver.findElementByName("submitButton");

driver.close();




	}

}
