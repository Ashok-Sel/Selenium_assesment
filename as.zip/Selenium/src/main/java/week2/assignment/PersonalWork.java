package week2.assignment;

import java.util.Scanner;

public class PersonalWork {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuffer s=new StringBuffer("iswarya");
		StringBuffer t=new StringBuffer("ashokaa");
		//String[] f1=s.split("");
		//String[] f2=t.split("");
		int len1=s.length();
		int len2=t.length();
		int count=0;
		for(int i=0;i<len1;i++)
		{
			
			for(int j=0;j<t.length();j++)
			{
				//System.out.println("vlaue of"+t);
				if(s.charAt(i)==t.charAt(j))
				{
				
			t=t.deleteCharAt(j);
			//System.out.println(t);
			break;
				}
			
			}
		}	
		
		//System.out.println(t);
		
	int lengtht=len2-t.length();
	int lengths=len1-lengtht;
	int flamesLen=lengths+t.length();
	System.out.println(flamesLen);
	
		
	}
}
