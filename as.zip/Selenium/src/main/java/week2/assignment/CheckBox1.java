package week2.assignment;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CheckBox1 {

	public static void main(String[] args) throws InterruptedException {
		
		
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		String title = driver.getTitle();
System.out.println(title);

driver.manage().window().maximize();

driver.findElementByName("USERNAME").sendKeys("DemoSalesManager");
driver.findElementById("password").sendKeys("crmsfa");
driver.findElementByClassName("decorativeSubmit").click();
driver.findElementByLinkText("CRM/SFA").click();

driver.findElementByLinkText("Leads").click();
driver.findElementByLinkText("Create Lead").click();
driver.findElementById("createLeadForm_companyName").sendKeys("Testleaf");
driver.findElementById("createLeadForm_firstName").sendKeys("Ashok");
driver.findElementById("createLeadForm_lastName").sendKeys("s");

WebElement Source = driver.findElementById("createLeadForm_dataSourceId");	
Select Dropdown = new Select(Source);
Dropdown.selectByVisibleText("Employee");

WebElement marketingcamapign = driver.findElementById("createLeadForm_marketingCampaignId");
Select markdropdown = new Select(marketingcamapign);
markdropdown.selectByValue("9001");

WebElement industry = driver.findElementById("createLeadForm_industryEnumId");
Select industryDropdown = new Select(industry);
industryDropdown.selectByIndex(15);

WebElement ownership = driver.findElementById("createLeadForm_ownershipEnumId");
Select ownershipdropdown =new  Select(ownership);
ownershipdropdown.selectByIndex(5);

WebElement country = driver.findElementById("createLeadForm_generalCountryGeoId");
Select countrydropdown=new Select(country);
countrydropdown.selectByValue("IND");

driver.findElementByName("submitButton").click();

driver.close();









//WebElement findElementByXPath = driver.findElementByXPath("//select[@id='createLeadForm_dataSourceId']//..//option");

//Select ele1 = new Select(findElementByXPath);

//ele1.selectByVisibleText("Cold Call");
//ele1.selectByVisibleText("Direct Mail");

	}

}
