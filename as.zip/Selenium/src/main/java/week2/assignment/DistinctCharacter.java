package week2.assignment;

import java.util.Arrays;

public class DistinctCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String input="Amazon India Private Limited";
		String t=input.replace(" ", "").trim();
		char[] s=t.toCharArray();
		char[] cloned=t.toCharArray();
		int length = t.length();
		System.out.println(t);
		String  a="";
		
		
		for(int i=0;i<=s.length-1;i++)
		{
			String n=Character.toString(s[i]);
			if(!a.contains(n))
			{
				a=a.concat(n);
			}
			
		}
		System.out.println("Output: "+a);
	
}
}
