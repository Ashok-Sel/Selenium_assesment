package week2.assignment;

import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment1FindLeads {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leaftaps.com/opentaps/control/main");
		driver.findElementByXPath("//input[@name='USERNAME']").sendKeys("DemoCSR");
		driver.findElementByXPath("//input[@name='PASSWORD']").sendKeys("crmsfa");;
		driver.findElementByXPath("//input[@type='submit']").click();
		driver.findElementByXPath("//a[contains(text(),'CRM/SFA')]").click();
		driver.findElementByXPath("//a[contains(text(),'Leads')]").click();
		driver.findElementByXPath("//a[contains(text(),'Find Leads')]").click();
		driver.findElementByXPath("(//input[@name='firstName'])[3]").sendKeys("ashok");
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(3000);
		
		driver.findElementByXPath("(//div/a)[40]").click();
		System.out.println("Is title equals " +driver.getTitle().contains("View Lead | opentaps CRM"));
		driver.findElementByLinkText("Edit").click();
		String companyName = "Test";
		driver.findElementById("updateLeadForm_companyName").sendKeys(companyName);
		driver.findElementByXPath("(//input[@name='submitButton'])[1]").click();
		boolean eleComapnyName= driver.findElementByXPath("//span[@id='viewLead_companyName_sp']").getText().contains(companyName);
		System.out.println("properly Updated: "+ eleComapnyName);
		
		driver.close();
			


	}

}
