package week2.assignment;

import java.util.Arrays;

public class AssignmentString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String input="PayPal India";
		String t=input.replace(" ", "").trim();
		char[] s=t.toCharArray();
		char[] cloned=t.toCharArray();
		int length = t.length();
		System.out.println(t);
		String  a="";
		
		
		for(int i=0;i<=s.length-1;i++)
		{
			
			int Count = 0;
			for(int j=0;j<=cloned.length-1;j++)
			{
				if(s[i]==cloned[j])
				{
					Count++;
					
				}
			
			}
			if(Count == 1)
			{
				String e = Character.toString(s[i]);
				a=a.concat(e);
				
			}
			
		}
		System.out.println("Output: "+a);
	
}
}
