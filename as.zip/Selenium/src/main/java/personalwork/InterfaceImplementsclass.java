package personalwork;

import personal2.point2;

public class InterfaceImplementsclass implements InterfaceExample,kkkk{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//point2 point= new point2();
		int i=0;
		InterfaceImplementsclass obj=new InterfaceImplementsclass();
		System.out.println(i);
	    System.out.println("jh"+i);
	    //point2 fdg=new point2();
	    //fdg.add();
	    

	}

	public void username() {
		// TODO Auto-generated method stub
		
	}

	public void accessCrm() {
		// TODO Auto-generated method stub
		
	}

	public void createLead() {
		// TODO Auto-generated method stub
		
	}

	public void ghlk() {
		// TODO Auto-generated method stub
		
	}

	

}
