package personalwork;

public interface kkkk {
	public void ghlk();

}
