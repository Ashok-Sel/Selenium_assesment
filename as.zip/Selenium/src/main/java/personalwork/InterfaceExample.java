package personalwork;

public interface InterfaceExample {

	public void username();
	public void accessCrm();
	void createLead();
	
	
}
