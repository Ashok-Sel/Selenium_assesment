package week3.day1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Selectable {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
ChromeDriver driver =new ChromeDriver();
driver.navigate().to("http://leafground.com/pages/selectable.html");
driver.manage().window().maximize();
Actions builder = new Actions(driver);
WebElement findElementByXPath = driver.findElementByXPath("//ol/li[text()='Item 7']");
WebElement findElementByXPath3 = driver.findElementByXPath("//ol/li[text()='Item 4']");
builder.clickAndHold(findElementByXPath).release(findElementByXPath3).perform();
	}

}
