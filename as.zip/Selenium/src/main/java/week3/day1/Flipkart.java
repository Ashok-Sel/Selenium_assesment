package week3.day1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Flipkart {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
ChromeDriver driver =new ChromeDriver();
driver.navigate().to("https://www.flipkart.com/");
driver.manage().window().maximize();
driver.findElementByXPath("//button[text()='✕']").click();
Actions builder = new Actions(driver);
WebElement findElementByXPath = driver.findElementByXPath("//span[text()='TVs & Appliances']");
builder.moveToElement(findElementByXPath).perform();
System.out.println("dfdf");
Thread.sleep(3000);
WebElement findElementByXPath2 = driver.findElementByXPath("(//a[text()='LG'])[2]");
findElementByXPath2.click();
Thread.sleep(5000);
String text = driver.findElementByXPath("(//div[text()='LG 1.5 Ton 5 Star Split Dual Inverter AC  - White'])[1]").getText();
System.out.println(text);
	}

}
