package week3.assignment;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LeafGroundTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.navigate().to("http://leafground.com/pages/table.html");
		driver.manage().window().maximize();
		WebElement table=driver.findElementByXPath("//table[@class='display']");
		List<WebElement> rows=table.findElements(By.tagName("tr"));
		int rowssize = rows.size();
		WebElement firstRow = rows.get(1);
		System.out.println(rowssize);
		List<WebElement> Column = firstRow.findElements(By.tagName("td"));
		int Columnsize = Column.size();
		System.out.println(Columnsize);
		List<WebElement> findElementsByXPath = driver.findElementsByXPath("//table//tr");
		int sz=findElementsByXPath.size();
		System.out.println(sz);
		
		for(int i=2;i<sz;i++)
		{
			String text = driver.findElementByXPath("//table//tr["+i+"]/td[1]").getText();
			if(text.contains("Learn to interact with Elements"))
			{
				String text2 = driver.findElementByXPath("//table//tr["+i+"]/td[2]").getText();
				
				System.out.println(text2);
			}
			
			/*List<WebElement> findElements = rows.get(i).findElements(By.tagName("td"));
			//System.out.println("fssf"+findElements);
			String text = findElements.get(0).getText();
			//System.out.println(text);
			if(text.contains("Learn to interact with Elements"))
			{
				
				 
				String colValue = findElements.get(1).getText();
				System.out.println(colValue);
			}
		*/
		}
		
		
		
		

	}

}
