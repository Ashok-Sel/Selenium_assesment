package week3.assignment;

import java.util.Arrays;

public class ClassRoom2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] s= {"HCl","Wipro","Aspire System","CTS"};
		int len=s.length;
		Arrays.sort(s);
		System.out.println(len);
		for(int i=len-1;i>=0;i--)
		{
			System.out.println(s[i]);
		}
		
	}

}
