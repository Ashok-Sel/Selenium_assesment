package week3.assignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClassRoom1 {

	public static void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("https://erail.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		  WebElement sort=driver.findElementByXPath("//input[@title='View trains running on select date']");
		if(sort.isSelected())
		{
			sort.click();
		}
	WebElement source=driver.findElementByXPath("//input[@title='Type SOURCE station code or name']");
	if(source.isEnabled())
	{
		source.clear();
		source.sendKeys("Che");
	}
	//Thread.sleep(3000);
	List<WebElement> stations=driver.findElementsByXPath("//div[starts-with(@title,'Che')]");
	//System.out.println(stations.size());
	for (WebElement e:stations)
	{
		//System.out.println(e.getText());
		if(e.getText().contains("Chembur"))
		{
			e.click();
			
		}
		continue;
		
	}
	WebElement source1	=driver.findElementByXPath("//input[@title='Enter DESTINATION station code or name']");
	if(source1.isEnabled())
	{
		source1.clear();
		source1.sendKeys("mum");
	}
	//Thread.sleep(3000);
	List<WebElement> stations1=driver.findElementsByXPath("//div[starts-with(@title,'Mum')]");
	//System.out.println(stations1.size());
	for (WebElement e1:stations1)
	{
		
		//System.out.println(e1.getText());
		if(e1.getText().contains("Mumbai Cst"))
		{
			e1.click();
		}
		
	}
	
	
	
	List<WebElement> trainNames = driver.findElementsByXPath("//table[@class='DataTable TrainList TrainListHeader']//tr");
	int z =trainNames.size();
	String Trainname3=driver.findElementByXPath("//table[@class='DataTable TrainList TrainListHeader']//tr[1]//td[2]").getText();
	System.out.println(z);
	
	List<String> train=new ArrayList<String>();
	for(int i=1;i<z;i++)
		
	{
		//System.out.println("for in");
		String Trainname2=driver.findElementByXPath("//table[@class='DataTable TrainList TrainListHeader']//tr["+i+"]//td[2]").getText();
		
	 train.add(Trainname2);
		
	}
	System.out.println("sizes"+train.size());
	
Collections.sort(train);
for(String s:train)
{
	System.out.println(s);
}
	}

}
