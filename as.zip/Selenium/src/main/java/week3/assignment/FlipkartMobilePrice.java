package week3.assignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class FlipkartMobilePrice {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.navigate().to("https://www.flipkart.com/");
		driver.manage().window().maximize();
		driver.findElementByXPath("//button[text()='✕']").click();
		Actions builder = new Actions(driver);
		WebElement electronicsTab = driver.findElementByXPath("//span[text()='Electronics']");
		builder.moveToElement(electronicsTab).perform();
		Thread.sleep(3000);
		driver.findElementByXPath("//a[@title='Mi']").click();
		Thread.sleep(3000);
		List<WebElement> totalPrice=driver.findElementsByXPath("//div[@class='_1vC4OE _2rQ-NK']");
		System.out.println(totalPrice.size());
		List<Integer> price1= new ArrayList<Integer>(); 
		int text1 =0;
		String text="";
		for(WebElement price:totalPrice)
		{
			 text = price.getText().replaceAll("₹", "").replace(",", "");
			text1=Integer.parseInt(text);
			price1.add(text1);
		}
		int max = Collections.max(price1);
		System.out.println(max);
		
	}

}
