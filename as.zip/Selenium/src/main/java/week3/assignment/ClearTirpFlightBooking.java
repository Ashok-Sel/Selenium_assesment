package week3.assignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ClearTirpFlightBooking {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	ChromeDriver driver= new ChromeDriver();
	driver.navigate().to("https://www.cleartrip.com/");
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElementByXPath("//strong[text()='Round trip']/preceding-sibling::input").click();
	driver.findElementByXPath("//strong[text()='From']/../../following::input[1]").sendKeys("chennai",Keys.TAB);
	driver.findElementByXPath("//strong[text()='To']/../../following::input[1]").sendKeys("new york",Keys.TAB);
	driver.findElementByXPath("//strong[text()='Depart on']/../../following::input[1]").sendKeys("06042020",Keys.TAB);
	//Thread.sleep(2000);
	driver.findElementByXPath("//strong[text()='Return on']/../../following::input[1]").sendKeys("07042020",Keys.TAB);
	//Thread.sleep(2000);
	WebElement Adults = driver.findElementByXPath("//select[@id='Adults']");	
	System.out.println("hjghfdfgd");
	Select dropdown = new Select(Adults);
	dropdown.selectByVisibleText("6");
	WebElement Adults2 = driver.findElementByXPath("//select[@id='Childrens']");	
	Select dropdown2 = new Select(Adults2);
	dropdown2.selectByVisibleText("0");
	WebElement Adults3 = driver.findElementByXPath("//select[@id='Infants']");	
	Select dropdown3 = new Select(Adults3);
	dropdown3.selectByVisibleText("3");
	driver.findElementByXPath("//strong[contains(text(),' More options:')]").click();
	WebElement Adults4 = driver.findElementByXPath("(//select)[3]");	
	Select dropdown4 = new Select(Adults4);
	dropdown4.selectByIndex(3);
	driver.findElementByXPath("//label[text()='Preferred Airline ']/../following::input[1]").sendKeys("Emirates",Keys.TAB);
	driver.findElementByXPath("//input[@title='Search flights']").click();
	Thread.sleep(3000);
	//driver.close();
	
	
	
	
	}

}
	