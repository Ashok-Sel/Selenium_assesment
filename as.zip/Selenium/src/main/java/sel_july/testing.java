package sel_july;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class testing {

	@Test
	public void testings() throws MalformedURLException {
		// TODO Auto-generated method stub


		/*System.setProperty("webdriver.ie.driver", "./drivers/IEDriverServer.exe");

		WebDriver driver=new InternetExplorerDriver();  
		driver.navigate().to("https://autoportal.com/");*/
		
		/*System.setProperty("webdriver.gecko.driver","./drivers/geckodriver.exe");

	       DesiredCapabilities capabilities=new DesiredCapabilities();
	       capabilities.firefox();
	       capabilities.acceptInsecureCerts();
		WebDriver driver=new FirefoxDriver();
		driver.navigate().to("https://autoportal.com/");*/
		
		//Chrome Driver
		
		WebDriver driver=null;
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeOptions options=new ChromeOptions();
		options.addArguments("chrome.switches","--disable-extensions");
		options.addArguments("--disable-notifications");
		//options.addArguments("--kiosk");
		
		DesiredCapabilities capabilities=new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
		capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		capabilities.setBrowserName("chrome");
		capabilities.setPlatform(Platform.WINDOWS);
		driver=new ChromeDriver(capabilities);
		driver.navigate().to("https://autoportal.com/");
		
		
		
		
		
		
		
		
		



	}

}
