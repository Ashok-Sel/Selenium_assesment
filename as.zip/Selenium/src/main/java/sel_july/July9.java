package sel_july;


import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.Point;


public class July9 {


	public static WebDriverWait wait;
	public static ChromeDriver driver;
	public static JavascriptExecutor js;
	public static Actions action;


	public static void main(String[] args) throws IOException, InterruptedException {




		//Test case prerequisite
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		driver=new ChromeDriver(option);
		option.addArguments("-disable-notifications");
		driver.navigate().to("https://www.zoomcar.com/chennai/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		//general functions
		action=new Actions(driver);
		js=(JavascriptExecutor)driver;

		//click on the wonderful journey
		eClick("//a[text()='Start your wonderful journey']");	

		//click on popular pick up point
		eClick("//div[contains(text(),'Thuraipakkam')]");

		//click on next
		eClick("//button[text()='Next']");

		//select from date
		
		
		// 4. Select tomorrow's date and time as 9:00 AM as start date and time and
				// Click Next
				driver.findElementByXPath("(//div[@class = 'day low-price'])[1]").click();
				driver.findElementByXPath("//span[text() = '09:00']").click();
				driver.findElementByClassName("proceed").click();
				Thread.sleep(2000);

				// 5. Click on Show More and Select tomorrow's date and Select time as 6:00 PM
				// as end date and Click Done
				driver.findElementByClassName("show-more").click();
				driver.findElementByXPath("(//li[@class = 'active low-price'])[1]").click();
				driver.findElementByXPath("//span[text() = '18:00']").click();
				driver.findElementByXPath("//button[text() = 'Done']").click();
				Thread.sleep(2000);

		
		
		
		
		//take screenshot
		
		

		
		
		WebDriverWait wait = new WebDriverWait(driver, 20);
		WebElement pickupdrop = driver.findElementByXPath("(//div[@class='item'])[2]");
		wait.until(ExpectedConditions.visibilityOf(pickupdrop));
		File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		BufferedImage  fullImg = ImageIO.read(screenshot);
		Point point = pickupdrop.getLocation();
		int eleWidth = pickupdrop.getSize().getWidth();
		int eleHeight = pickupdrop.getSize().getHeight();
		BufferedImage eleScreenshot= fullImg.getSubimage(point.getX(), point.getY(),eleWidth, eleHeight);
		ImageIO.write(eleScreenshot, "png", screenshot);
		File DestFile = new File("src/main/java/pidrop.png");
		FileUtils.copyFile(screenshot, DestFile);
	
	   //validate the pickup time
		
		String pickupTime = driver.findElementByXPath("(//div[@class='time']//div)[2]").getText();
		String dropTime = driver.findElementByXPath("(//div[@class='time']//div)[4]").getText();
		if((pickupTime.contains("09:00 AM"))&& (dropTime.contains("06:00 PM")))
		{
			System.out.println("pickup time is 9 AM and drop time is 6 PM");
		}
		
		//click price high to low
		eClick("//div[text()=' Price: High to Low ']");
		
		
		//sorting price
		List<WebElement> price=driver.findElementsByXPath("//div[@class='new-price']");
		List<Integer> priceNum=new ArrayList<Integer>();
		
		
		for(WebElement s:price)
		{
			priceNum.add(Integer.parseInt(s.getText().replaceAll("[^0-9]", "")));
		}
		 
		int size = price.size();
		
		if(Collections.max(priceNum)==priceNum.get(0)&&(Collections.min(priceNum)==priceNum.get(size-1)))
		{
			
			System.out.println("Sorted successfully");
		}
		
		List<WebElement> carName=driver.findElementsByXPath("//div[@class='details']//h3");
		Map<String,Integer> obj=new LinkedHashMap<String,Integer>();
		
		Integer h=0;
		String d="";
		
		
	  for(int i=0;i<=carName.size()-1;i++)
	  {
		  
		d=carName.get(i).getText();
		h=Integer.parseInt(price.get(i).getText().replaceAll("[^0-9]", ""));
		obj.put(d, h);
	  }
		
		for(Entry<String,Integer> g:obj.entrySet())
		{
			System.out.println(g);
		}

		
		WebElement img=eFind("(//div[@class='details'])[1]");
		wait.until(ExpectedConditions.visibilityOf(img));
		File screenshot1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		BufferedImage read=ImageIO.read(screenshot1);
        Point location2 = img.getLocation();
        int height = img.getSize().getHeight();
        int width = img.getSize().getWidth();
        BufferedImage write=read.getSubimage(location2.getX(), location2.getY(),width,height);
        ImageIO.write(write, "png", screenshot1);
        File location=new File("src/main/java/highestprice.png");
		FileUtils.copyFile(screenshot1, location);
		
	}

	public static void eClick(String xpath)
	{
		driver.findElementByXPath(xpath).click();
	}
	public static WebElement eFind(String xpath)
	{
		return driver.findElementByXPath(xpath);
	}

	public static void sKeys(String xpath,String content)
	{
		driver.findElementByXPath(xpath).sendKeys(content);
	}
}
