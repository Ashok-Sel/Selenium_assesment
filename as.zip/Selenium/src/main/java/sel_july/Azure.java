package sel_july;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.mongodb.assertions.Assertions;



public class Azure {
 
	public void fileDownloaded(String file)
	{
	String path="C:\\Users\\Thirumalai\\Downloads";

	Assert.assertTrue(isFileDownloaded(path,file),"failed to download");
	
	System.out.println(file +"downloaded successfully");
	
	
	}
	
	public boolean isFileDownloaded(String paths,String files)
	{
		boolean flag=false;
		
		File dir=new File(paths);
		File[] dir_list=dir.listFiles();
		
		for(int i=0;i<dir_list.length-1;i++)
		{
			if(dir_list[i].toString().contains(files))
			{
				return flag=true;
			}
			break;
			
		}
		return flag;
		
	}
	
	public static void checkfiles(String filename) {
		File f = new File("C:\\Users\\Thirumalai\\Downloads\\" + filename);

		if (f.exists() == true) {
			System.out.println("File downloaded sucessfully");
		} else {
			System.out.println("File not downloaded");
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions options=new ChromeOptions();
		ChromeDriver driver=new ChromeDriver(options);
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		options.addArguments("--disable-notifications");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.navigate().to("https://azure.microsoft.com/en-in/");
		driver.findElementByXPath("//a[@title='Pricing']").click();
	    driver.findElementByXPath("//a[contains(text(),'Pricing calculator')]").click();
	    driver.findElementByXPath("//button[text()='Containers']").click();
	    driver.findElementByXPath("(//span[text()='Container Instances'])[3]").click();
	    WebDriverWait wait = new WebDriverWait(driver,20);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='View']"))).click();
	    WebElement findElementByXPath = driver.findElementByXPath("//select[@name='region']");
	    Select region=new Select(findElementByXPath);
	    region.selectByVisibleText("South India");
	    Actions bulider=new Actions(driver);
	    driver.findElementByXPath("//input[@name='seconds']").clear();
	   driver.findElementByXPath("//input[@name='seconds']").click();
	   bulider.sendKeys(Keys.ARROW_RIGHT).perform();
	   bulider.sendKeys(Keys.BACK_SPACE).perform();
	   Thread.sleep(1000);
	   bulider.sendKeys(Keys.ARROW_LEFT).perform();
	   driver.findElementByXPath("//input[@name='seconds']").sendKeys("18000");
	   WebElement findElementByXPath2 = driver.findElementByXPath("//select[@name='memory']");
	   Select memory=new Select(findElementByXPath2);
	   memory.selectByVisibleText("4 GB");
	   driver.findElementByXPath("//button[@name='devTestSelected']").click();
	   WebElement findElementByXPath3 = driver.findElementByXPath("//select[@class='select currency-dropdown']");
	   Select currency=new Select(findElementByXPath3); 
	   currency.selectByVisibleText("Indian Rupee (₹)");
	   String mothlycost = driver.findElementByXPath("//span[text()='Monthly cost']/following::span[1]").getText().replaceAll("[^0-9.]", "");
	   System.out.println(mothlycost);
	   driver.findElementByXPath("//button[text()='Export']").click();
	   Thread.sleep(2000);
	   
	   checkfiles("ExportedEstimate.xlsx");
	   
	  
	   
	   driver.executeScript("window.scrollTo(0,-document.body.scrollHeight)");
		driver.findElementByXPath("//a[text()='Example Scenarios']").click();

		// CI/CD for containers click
		driver.findElementByXPath("//button[@title='CI/CD for Containers']").click();
		Thread.sleep(3000);

		// Click Add to Estimate
		WebElement addtoestimates = driver.findElementByXPath("//button[text()='Add to estimate']");
		JavascriptExecutor executor1 = (JavascriptExecutor) driver;
		executor1.executeScript("arguments[0].click();", addtoestimates);
		Thread.sleep(5000);

		// Change the Currency as Indian Rupee
		WebElement currency1 = driver.findElementByXPath("//select[@class='select currency-dropdown']");
		new Select(currency1).selectByValue("INR");
		Thread.sleep(3000);

		// Enable SHOW DEV/TEST PRICING
		driver.findElementByXPath("//button[@name='devTestSelected']").click();
		Thread.sleep(2000);

		// Export the Estimate
		driver.findElementByXPath("//button[@class='calculator-button button-transparent export-button']").click();
		Thread.sleep(2000);

		// Verify the downloded file in the local folder
		checkfiles("ExportedEstimate.xlsx");
		
		//close the Browser
		driver.close();

	    
	   
	   
	    
	    
	    
		
		
	}
	
}
