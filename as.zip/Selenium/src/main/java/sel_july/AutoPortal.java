package sel_july;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.paulhammant.ngwebdriver.ByAngular;
import com.paulhammant.ngwebdriver.NgWebDriver;

public class AutoPortal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		JavascriptExecutor js= (JavascriptExecutor)driver;
		NgWebDriver ng=new NgWebDriver(js);
		
		driver.get("https://autoportal.com/");
		driver.manage().window().maximize();
		
		driver.findElementByXPath("//span[@data-type='city-title']").click();
		
		driver.findElementByXPath("//input[@value='Select City']").click();
		
		driver.findElementByXPath("//input[@value='Select City']").sendKeys("chennai");
		WebDriverWait wait = new WebDriverWait(driver,20);
		WebElement dropdown = driver.findElementByXPath("//li[@class='ui-menu-item']/span[text()='Chennai']");
		
		wait.until(ExpectedConditions.visibilityOf(dropdown));
		dropdown.click();
	}
	

}
