package sel_july;

import static org.testng.Assert.assertTrue;

import java.io.File;

import org.testng.Assert;

public class FileExist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		result("ddfs");
		System.out.println("continue");
		
		
		
	}
		
	public static void result(String File)
	{
	  try
	  {
		  Assert.assertTrue(test(File));
		  System.out.println(File +" downloaded successfully");
	  }
	  catch(Exception e)
	  {
	  System.out.println("not exist");
	  }
	}
	public static boolean test(String fileName)
	{
		File dir=new File("C:\\Users\\Thirumalai\\Downloads");
		File[] list=dir.listFiles();
		boolean flag=false;
		for(int i=0;i<list.length-1;i++)
		{
			if(list[i].toString().contains(fileName))
			{
				
				return flag=true;
			}
			
			
		}
		return flag;
		
		
	}
}
