package sel_july;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Just {
	
	public static ChromeDriver driver;
	public static WebDriverWait wait;
	public static JavascriptExecutor js;
	public static Actions action;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions option=new ChromeOptions();
		driver= new ChromeDriver(option);
		option.addArguments("--disable-notifications");
		driver.manage().deleteAllCookies();
		driver.navigate().to("https://azure.microsoft.com/en-in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		//commom functions
		wait=new WebDriverWait(driver,20);
		js=(JavascriptExecutor)driver;
		action=new Actions(driver);
		
		
		WebElement df=eFind("(//a[text()='See all products (200+)'])[1]");
		
		//js.executeScript("arguments[0].scrollIntoView()", df);
		
		
		
		
	}
	
	//Element click
			public static void eClick(String xpath) 
			{
				driver.findElementByXPath(xpath).click();
			
			}

			//find Element
			public static WebElement eFind(String xpath) 
			{
				return driver.findElementByXPath(xpath);
			
			}
			
			//sendKeys
			public static void sendKeys(String xpath,String input)
			{
				driver.findElementByXPath("").sendKeys("");
			}
           

}
