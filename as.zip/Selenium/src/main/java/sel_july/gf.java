package sel_july;

import java.io.File;

import org.testng.Assert;

public class gf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		new gf().finals("Iswarya Resume");
	}
	
	
	public void finals(String name)
	
	{
      Assert.assertTrue(testing(name));	
      System.out.println("success");
	}
	public static boolean testing(String fileName)
	{
		boolean flag=false;
		File dir=new File("C:\\Users\\Thirumalai\\Downloads");
		File[] dir_list=dir.listFiles();
		
		for(int i=0;i<=dir_list.length-1;i++)
		{
			
			if(dir_list[i].toString().contains(fileName))
			{
				System.out.println("dsgdsgd");
				return flag=true;
			}
			
			
		}
		return false;
	
		
		
	}
	
	
	
	

}
