package testcase;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ProcessSpecificAttributes.ProcessSpecific;

public class CreateLead extends ProcessSpecific

{

	
	

	
	
	@Test(dataProvider="getDetails")
	public void main1(String c,String k,String l,String m) {

		/*System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		String title = driver.getTitle();
System.out.println(title);

driver.findElementByName("USERNAME").sendKeys("DemoSalesManager");
driver.findElementById("password").sendKeys("crmsfa");
driver.findElementByClassName("decorativeSubmit").click();
driver.findElementByLinkText("CRM/SFA").click();
		 */
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Create Lead").click();
		driver.findElementById("createLeadForm_companyName").sendKeys(c);
		driver.findElementById("createLeadForm_lastName").sendKeys(k);
		driver.findElementById("createLeadForm_firstName").sendKeys(m);
		driver.findElementByClassName("smallSubmit").click();


	}

}

