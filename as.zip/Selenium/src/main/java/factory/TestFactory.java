package factory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;



public class TestFactory{

	public int i = 1;
	public static RemoteWebDriver driver;
	public static Properties prop;
	
	public TestFactory()
	{
		this.driver=driver;	
	}

	public static void loadProperty() {
		prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("./objectRep/english.properties")));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void unloadProperty() {
		prop = null;
	}

	final String IE_Path=System.getProperty("user.dir")+File.separator+"drivers"
			+File.separator+"IEDriverServer.exe";
	
	final String FF_Path=System.getProperty("user.dir")+File.separator+"drivers"
			+File.separator+"geckodriver.exe";
	final String Chrome_Path=System.getProperty("user.dir")+File.separator+"drivers"
			+File.separator+"chromedriver.exe";
	
	public WebDriver getIEDriver(String browser,String url) {
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();;
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
		capabilities.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
		capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		capabilities.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, false);
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		
		InternetExplorerOptions option = new InternetExplorerOptions();
		option.merge(capabilities);
		
		File file=new File(IE_Path);
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
        WebDriver driver=new InternetExplorerDriver(option);
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(1L, TimeUnit.SECONDS);
        return driver;
	}
	
	public WebDriver getChromeDriver() throws Exception {
		WebDriver driver=null;
		File file=new File(Chrome_Path);
		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
		
		DesiredCapabilities capabilities=new DesiredCapabilities();
		//capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
		capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		capabilities.setBrowserName("chrome");
		capabilities.setPlatform(Platform.WINDOWS);
		
		ChromeOptions options=new ChromeOptions();
		options.addArguments("chrome.switches","--disable-extensions");
		options.addArguments("--disable-notifications");
		options.addArguments("--kiosk");
		
		
		driver=new ChromeDriver(options);
		driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(1L, TimeUnit.SECONDS);
		return driver;
	}
	
	public WebDriver getFFDriver() throws Exception {
		WebDriver driver=null;
		File file=new File(FF_Path);
		System.setProperty("webdriver.gecko.driver", file.getAbsolutePath());
		driver=new FirefoxDriver();
		driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(1L, TimeUnit.SECONDS);
		return driver;
	}

		
		
		
		

	public static void launchBrowserAndUrl(String browser, String url) {
		try {
			if(browser.equalsIgnoreCase("chrome")){
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				driver = new ChromeDriver();
			} else if (browser.equalsIgnoreCase("firefox")){
				System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
				driver = new FirefoxDriver();
			}
			driver.get(url);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			System.out.printf("The browser: "+browser+" launched successfully", "PASS");
		} catch (WebDriverException e) {			
			System.out.printf("The browser: "+browser+" could not be launched", "FAIL");
			
		}
	}


	public static void launchChromeAndUrl(String url) {
		try {
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(url);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			System.out.printf("The browser: Chrome launched successfully", "PASS");
		} catch (WebDriverException e) {			
			System.out.printf("The browser: Chrome could not be launched", "FAIL");
		}
	}

	public static  WebElement findElement(String locator, String locValue) {
		try {
			switch(locator) {
			case "id"	 : return driver.findElementById(locValue);
			case "class" : return driver.findElementByClassName(locValue);
			case "name" : return driver.findElementByName(locValue);
			case "link" : return driver.findElementByLinkText(locValue);
			case "partialLink" : return driver.findElementByPartialLinkText(locValue);
			case "tagname" : return driver.findElementByTagName(locValue);
			case "xpath" : return driver.findElementByXPath(locValue);
			case "cssSelect" : return driver.findElementByCssSelector(locValue);
			}
		} catch (NoSuchElementException e) {
			System.out.printf("The element with locator "+locator+" not found.","FAIL");
		} catch (WebDriverException e) {
			System.out.printf("Unknown exception occured while finding "+locator+" with the value "+locValue, "FAIL");
		}
		return null;
	}

	public static WebElement findElementById(String locValue) {
		return driver.findElementById(locValue);
	}


	public static List<WebElement> findElements(String type, String locValue) {
		try {
			switch(type) {
			case "id"	 : return driver.findElementsById(locValue);
			case "class" : return driver.findElementsByClassName(locValue);
			case "name" : return driver.findElementsByName(locValue);
			case "link" : return driver.findElementsByLinkText(locValue);
			case "partialLink" : return driver.findElementsByPartialLinkText(locValue);
			case "tagname" : return driver.findElementsByTagName(locValue);
			case "xpath" : return driver.findElementsByXPath(locValue);
			case "cssSelect" : return driver.findElementsByCssSelector(locValue);
			}
		} catch (NoSuchElementException e) {
			System.out.printf("The element with locator "+type+" not found.","FAIL");
		} catch (WebDriverException e) {
			System.out.printf("Unknown exception occured while finding "+type+" with the value "+locValue, "FAIL");
		}
		return null;
	}

	public static void ElementClearAndType(WebElement ele, String data) {
		try {
			ele.clear();
			ele.sendKeys(data);
			System.out.printf("The data: "+data+" entered successfully in the field :"+ele, "PASS");
		} catch (InvalidElementStateException e) {
			System.out.printf("The data: "+data+" could not be entered in the field :"+ele,"FAIL");
		} catch (WebDriverException e) {
			System.out.printf("Unknown exception occured while entering "+data+" in the field :"+ele, "FAIL");
		}
	}

	public static void clickWithNoSnap(WebElement ele) {
		String text = "";
		try {
			ele.click();			
			System.out.printf("The element :"+text+"  is clicked.", "PASS", false);
		} catch (InvalidElementStateException e) {
			System.out.printf("The element: "+text+" could not be clicked", "FAIL", false);
		} catch (WebDriverException e) {
			System.out.printf("Unknown exception occured while clicking in the field :","FAIL", false);
		} 
	}


	public static void ElementClick(WebElement ele) {
		String text = "";
		try {			
			ele.click();
			System.out.printf("The element "+text+" is clicked", "PASS");
		} catch (InvalidElementStateException e) {
			System.out.printf("The element: "+text+" could not be clicked", "FAIL");
		} catch (WebDriverException e) {
			System.out.printf("Unknown exception occured while clicking in the field :", "FAIL");
		} 
	}

	public static String getTitle() {		
		String bReturn = "";
		try {
			bReturn =  driver.getTitle();
		} catch (WebDriverException e) {
			System.out.printf("Unknown Exception Occured While fetching Title", "FAIL");
		} 
		return bReturn;
	}


	public static void selectDropDownUsingText(WebElement ele, String value) {
		try {
			new Select(ele).selectByVisibleText(value);
			System.out.printf("The dropdown is selected with text "+value,"PASS");
		} catch (WebDriverException e) {
			System.out.printf("The element: "+ele+" could not be found.", "FAIL");
		}
	}

	public static void selectDropDownUsingIndex(WebElement ele, int index) {
		try {
			new Select(ele).selectByIndex(index);
			System.out.printf("The dropdown is selected with index "+index,"PASS");
		} catch (WebDriverException e) {
			System.out.printf("The element: "+ele+" could not be found.", "FAIL");
		} 
	}


	public static void selectDropDownUsingValue(WebElement ele, String value) {
		try {
			new Select(ele).selectByValue(value);
			System.out.printf("The dropdown is selected with text "+value,"PASS");
		} catch (WebDriverException e) {
			System.out.printf("The element: "+ele+" could not be found.", "FAIL");
		}
	}

	public static boolean verifyTitle(String title) {
		boolean bReturn =false;
		try {
			if(getTitle().equals(title)) {
				System.out.printf("The title of the page matches with the value :"+title,"PASS");
				bReturn= true;
			}else {
				System.out.printf("The title of the page:"+driver.getTitle()+" did not match with the value :"+title, "FAIL");
			}
		} catch (WebDriverException e) {
			System.out.printf("Unknown exception occured while verifying the title", "FAIL");
		} 
		return bReturn;
	}

	public static boolean verifyExactText(WebElement ele, String expectedText) {
		try {
			if(getElementText(ele).equals(expectedText)) {
				System.out.printf("The text: "+getElementText(ele)+" matches with the value :"+expectedText,"PASS");
			}else {
				System.out.printf("The text "+getElementText(ele)+" doesn't matches the actual "+expectedText,"FAIL");
			}
		} catch (WebDriverException e) {
			System.out.printf("Unknown exception occured while verifying the Text", "FAIL");
		} 
		return false;
	}

	public static boolean verifyPartialText(WebElement ele, String expectedText) {
		try {
			if(getElementText(ele).contains(expectedText)) {
				System.out.printf("The expected text contains the actual "+expectedText,"PASS");
				return true;
			}else {
				System.out.printf("The expected text doesn't contain the actual "+expectedText,"FAIL");
			}
		} catch (WebDriverException e) {
			System.out.printf("Unknown exception occured while verifying the Text", "FAIL");
		} 
		return false;
	}

	public static boolean verifyExactAttribute(WebElement ele, String attribute, String value) {
		try {
			if(getTypedText(ele, attribute).equals(value)) {
				System.out.printf("The expected attribute :"+attribute+" value matches the actual "+value,"PASS");
				return true;
			}else {
				System.out.printf("The expected attribute :"+attribute+" value does not matches the actual "+value,"FAIL");
			}
		} catch (WebDriverException e) {
			System.out.printf("Unknown exception occured while verifying the Attribute Text", "FAIL");
		} 
		return false;
	}

	public static void verifyPartialAttribute(WebElement ele, String attribute, String value) {
		try {
			if(getTypedText(ele, attribute).contains(value)) {
				System.out.printf("The expected attribute :"+attribute+" value contains the actual "+value,"PASS");
			}else {
				System.out.printf("The expected attribute :"+attribute+" value does not contains the actual "+value,"FAIL");
			}
		} catch (WebDriverException e) {
			System.out.printf("Unknown exception occured while verifying the Attribute Text", "FAIL");
		}
	}

	public static void verifyIsSelected(WebElement ele) {
		try {
			if(ele.isSelected()) {
				System.out.printf("The element "+ele+" is selected","PASS");
			} else {
				System.out.printf("The element "+ele+" is not selected","FAIL");
			}
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		}
	}

	public static boolean verifyIsDisplayed(WebElement ele) {
		try {
			if(ele.isDisplayed()) {
				System.out.printf("The element "+ele+" is visible","PASS");
				return true;
			} else {
				System.out.printf("The element "+ele+" is not visible","FAIL");
			}
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "f");
		} 
		return false;
	}

	public static void switchToWindowByIndex(int index) {
		try {
			Set<String> allWindowHandles = driver.getWindowHandles();
			List<String> allHandles = new ArrayList<>();
			allHandles.addAll(allWindowHandles);
			driver.switchTo().window(allHandles.get(index));
		} catch (NoSuchWindowException e) {
			System.out.printf("The driver could not move to the given window by index "+index,"PASS");
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		}
	}

	public static void switchToFrame(WebElement ele) {
		try {
			driver.switchTo().frame(ele);
			System.out.printf("switch In to the Frame "+ele,"PASS");
		} catch (NoSuchFrameException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		} 
	}


	public static void switchToFrameByIndex(int index) {
		try {
			driver.switchTo().frame(index);
			System.out.printf("switch In to the Frame "+index,"PASS");
		} catch (NoSuchFrameException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		}
	}


	public static void switchToFrameByIdName(String idOrName) {
		try {
			driver.switchTo().frame(idOrName);
			System.out.printf("switch In to the Frame "+idOrName,"PASS");
		} catch (NoSuchFrameException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		}

	}

	public static  void acceptAlert() {
		String text = "";		
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
			alert.accept();
			System.out.printf("The alert "+text+" is accepted.","PASS", false);
		} catch (NoAlertPresentException e) {
			System.out.printf("There is no alert present.","FAIL", false);
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL", false);
		}  
	}

	public static  void dismissAlert() {
		String text = "";		
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
			alert.dismiss();
			System.out.printf("The alert "+text+" is dismissed.","PASS", false);
		} catch (NoAlertPresentException e) {
			System.out.printf("There is no alert present.","FAIL", false);
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL", false);
		} 
	}

	public static String getAlertText() {
		String text = "";		
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
		} catch (NoAlertPresentException e) {
			System.out.printf("There is no alert present.","FAIL", false);
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL", false);
		} 
		return text;
	}

	public static long takeSnap(){
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L; 
		try {
			FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE) , new File("./reports/images/"+number+".png"));
		} catch (WebDriverException e) {
			System.out.println("The browser has been closed.");
		} catch (IOException e) {
			System.out.println("The snapshot could not be taken");
		}
		return number;
	}

	public static void closeBrowser() {
		try {
			driver.close();
			System.out.printf("The browser is closed","PASS", false);
		} catch (Exception e) {
			System.out.printf("The browser could not be closed","FAIL", false);
		}
	}

	public static void closeAllBrowsers() {
		try {
			driver.quit();
			System.out.printf("The opened browsers are closed","PASS", false);
		} catch (Exception e) {
			System.out.printf("Unexpected error occured in Browser","FAIL", false);
		}
	}


	public static void append(WebElement ele, String data) {
		try {
			ele.sendKeys(data);
			System.out.printf("The Data :"+data+" entered Successfully", "PASS");
		} catch (ElementNotInteractableException e) {
			System.out.printf("The Element "+ele+" is not Interactable", "FAIL");
		}		
	}


	public static  void clear(WebElement ele) {
		try {
			ele.clear();
			System.out.printf("The field is cleared Successfully", "PASS");
		} catch (ElementNotInteractableException e) {
			System.out.printf("The field is not Interactable", "FAIL");
		}		
	}


	public static String getElementText(WebElement ele) {
		String bReturn = "";
		try {
			bReturn = ele.getText();
		} catch (WebDriverException e) {
			System.out.printf("The element: "+ele+" could not be found.", "FAIL");
		}
		return bReturn;	
	}


	public static String getBackgroundColor(WebElement ele, String prop) {
		String cssValue = "";
		try {
			cssValue = ele.getCssValue("color");
			System.out.printf("The Element "+ele+"returns color", "PASS");			
		}catch (Exception e) {
			System.out.printf("The Element "+ele+"returns color", "FAIL");
		}
		return cssValue;

	}


	public static String getTypedText(WebElement ele, String attribute) {
		String bReturn = "";
		try {
			bReturn=  ele.getAttribute(attribute);
		} catch (WebDriverException e) {
			System.out.printf("The element: "+ele+" could not be found.", "FAIL");
		} 
		return bReturn;
	}



	public static  boolean verifyDisappeared(WebElement ele) {
		try {
			if(ele.isDisplayed()) {
				System.out.printf("The element "+ele+" is Displayed", "PASS");
				return true;
			} else {
				System.out.printf("The element "+ele+" is not Displayed", "FAIL");
			}
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		}
		return false;
	}


	public static  boolean verifyEnabled(WebElement ele) {
		try {
			if(ele.isEnabled()) {
				System.out.printf("The element "+ele+" is Enabled", "PASS");
				return true;
			} else {
				System.out.printf("The element "+ele+" is not Enabled", "FAIL");
			}
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		}
		return false;
	}



	public static Alert switchToAlert() {
		Alert alert = null;		
		try {
			alert = driver.switchTo().alert();
			System.out.printf("The alert is switched successfully.","PASS");
			return alert;
		} catch (NoAlertPresentException e) {
			System.out.printf("There is no alert present.","FAIL");
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		}  
		return alert;
	}


	public static void typeAlert(String data) {	
		try {
			Alert alert = driver.switchTo().alert();
			alert.sendKeys(data);
			alert.accept();
			System.out.printf("The alert "+data+" is accepted.","PASS");
		} catch (NoAlertPresentException e) {
			System.out.printf("There is no alert present.","FAIL");
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		} 

	}


	public static void switchToWindowByTitle(String title) {
		try {
			Set<String> allWindows = driver.getWindowHandles();
			for (String eachWindow : allWindows) {
				driver.switchTo().window(eachWindow);
				if (driver.getTitle().equals(title)) {
					break;
				}
				System.out.printf("The Window With Title :"+title+" is switched", "PASS");
			}
		}catch (NoSuchWindowException e) {
			System.out.printf("\"The Window With Title: "+title+" not found","FAIL");
		} catch (WebDriverException e) {
			System.out.printf("WebDriverException : "+e.getMessage(), "FAIL");
		}

	}


	public static  void defaultContent() {
		try {
			driver.switchTo().defaultContent();
		}catch (Exception e) {
		}

	}

	public static  boolean verifyUrl(String url) {
		if (driver.getCurrentUrl().equals(url)) {
			System.out.printf("The url: "+url+" matched successfully", "PASS");
			return true;
		} else {
			System.out.printf("The url: "+url+" not matched", "FAIL");
		}
		return false;
	}

	public static void waits(int count) {
		for (int i = 1; i <=count; i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}


}