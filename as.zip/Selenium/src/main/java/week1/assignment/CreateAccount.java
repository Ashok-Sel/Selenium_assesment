package week1.assignment;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CreateAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
 ChromeDriver driver = new ChromeDriver();
 driver.get("http://leaftaps.com/opentaps/");
 driver.manage().window().maximize();
 	WebElement input = driver.findElementByXPath("//label[contains(text(),'Username')]/..//input[contains(@id,username)]");
 input.sendKeys("DemoSalesManager");
 driver.findElementByXPath("//label[contains(text(),'Password')]/..//input[contains(@id,password)]").sendKeys("crmsfa");
 driver.findElementByXPath("//input[contains(@class,'decorativeSubmit')]").click();
 driver.findElementByXPath("//a[contains(text(),'CRM/SFA')]").click();
 driver.findElementByXPath("//a[contains(text(),'Create Account')]").click();
 driver.findElementByXPath("//span[contains(text(),'Account Name')]/..//../..//input[contains(@id,'accountName')]").sendKeys("ashok");;
 driver.findElementByXPath("//span[contains(text(),'Site Name')]/..//../..//input[contains(@id,'officeSiteName')]").sendKeys("test");
 driver.findElementByXPath("//span[contains(text(),'Local Name')]/..//../..//input[contains(@id,'groupNameLocal')]").sendKeys("names");
 driver.findElementByXPath("//span[contains(text(),'Annual Revenue')]/..//../..//input[contains(@id,'annualRevenue')]").sendKeys("1447");
 driver.findElementByXPath("//input[contains(@class,'smallSubmit')]").click();
 driver.close();
 
 
 
 
	}

}
