package week1.assignment;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ButtonPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		//URl
		driver.get("http://leafground.com/pages/Button.html");
		
		//position of x and y
		WebElement position = driver.findElementByXPath("//button[@id='position']");
        Point getposition =position.getLocation(); 
        System.out.println("Position of x and y -" +getposition);
          
        //color of an element
        WebElement Elecolor=driver.findElementByXPath("//button[@id='color']");
        String Elementcolor = Elecolor.getCssValue("background-color");
        System.out.println("Element color -" +Elementcolor);
        
        //Size of an element
        Dimension elesize = driver.findElementByXPath("//button[contains(text(),'What is my size?')]").getSize();
        System.out.println("Size of an given element is -"   + elesize);
        
        WebElement Homepage=driver.findElementByXPath("//button[@id='home']");
        Homepage.click();
         driver.close();	  
	}

}
