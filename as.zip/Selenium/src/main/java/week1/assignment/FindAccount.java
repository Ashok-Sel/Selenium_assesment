package week1.assignment;

import org.openqa.selenium.chrome.ChromeDriver;

public class FindAccount {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leaftaps.com/opentaps/control/login");
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByXPath("//a[contains(text(),'CRM/SFA')]").click();
		driver.findElementByLinkText("Accounts").click();
		driver.findElementByLinkText("Find Accounts").click();
		driver.findElementByXPath("(//input[@name='accountName'])[2]").sendKeys("Credit Limited Account");
		driver.findElementByXPath("//button[text()='Find Accounts']");
		driver.findElementByLinkText("Credit Limited Account").click();
		driver.findElementByLinkText("Edit").click();
		System.out.println(driver.findElementById("accountName").getAttribute("value").equals("Credit Limited Account"));
		System.out.println(driver.findElementByName("description").getText().equals("Sales account with a credit limit of $100 USD"));
		System.out.println(driver.getTitle().equals("Edit Account | opentaps CRM"));
		driver.close();
		
		
		
		
		
			

	}

}
