package week1.assignment;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Checkbox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver =new ChromeDriver();
		driver.navigate().to("http://leafground.com/pages/checkbox.html");
		
		//select the languages you know
		List<WebElement> findElementByXPath = driver.findElementsByXPath("//label[text()='Select the languages that you know?']//..//input[@type='checkbox']");
		int size = findElementByXPath.size();
		
		
		System.out.println(size);
		for(WebElement ele:findElementByXPath)
		{
		ele.click();	
		}
		
		//Select all the checkboxes
		
		List<WebElement> findElementByXPath1 = driver.findElementsByXPath("//label[text()='Select all below checkboxes ']//..//input[@type='checkbox']");
		int size1 = findElementByXPath1.size();
		
		
		System.out.println(size);
		for(WebElement ele1:findElementByXPath1)
		{
		ele1.click();	
		}
		//label[text()='Confirm Selenium is checked']//..//input[@type='checkbox']
		
		WebElement findElementByXPath2 = driver.findElementByXPath("//label[text()='Confirm Selenium is checked']//..//input[@type='checkbox']");

			System.out.println("Check the  Checkbox is selected " + findElementByXPath2.isSelected());
			
			List<WebElement> findElementByXPath3 = driver.findElementsByXPath("//label[text()='DeSelect only checked']//..//input[@type='checkbox']");
			int size3 = findElementByXPath3.size();
			System.out.println(size3);
			for(WebElement ele3:findElementByXPath3)
			{
				if(ele3.isSelected())
				{
					ele3.click();
				
				}
				
			}
			
	}

}
	