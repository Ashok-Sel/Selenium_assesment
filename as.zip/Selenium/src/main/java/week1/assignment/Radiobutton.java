package week1.assignment;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Radiobutton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/pages/radio.html");
		/*driver.findElementById("yes").click();*/

		//default selected radio button
		/*WebElement findElementByXPath = driver.findElementByXPath("//*[@id=\"contentblock\"]/section/div[2]/div/div/label[2]/input");
		WebElement findElementByXPath2 = driver.findElementByXPath("//*[@id=\"contentblock\"]/section/div[2]/div/div/label[3]/input");
		if(findElementByXPath.isSelected())
		{
			System.out.println("The selected button is Unchecked ");
			
		}
		else
			System.out.println("The selected button is Checked");*/
		
		//Age Group selection
		WebElement findElementByXPath3 = driver.findElementByXPath("(//input[@name='age'])[1]");
		WebElement findElementByXPath4 = driver.findElementByXPath("(//input[@name='age'])[2]");
		WebElement findElementByXPath5 = driver.findElementByXPath("(//input[@name='age'])[3]");
		
		int a = 15;	
		if(a <=20) {
			if(findElementByXPath3.isSelected())
			{
				
				System.out.println("already 1 to 20 years checked");
			}
			else
			{
				findElementByXPath3.click();
			}
		}
		if(a>20 && a<=40) { 
			if(findElementByXPath4.isSelected())
			{
				
				System.out.println("already 21 to 40 years checked");
			}
			else
			{
				findElementByXPath4.click();
			}
		}
		if(a>40) { 
			if(findElementByXPath5.isSelected())
			{
				
				System.out.println("already 40 years checked");
			}
			else
			{
				findElementByXPath5.click();
			}
		}
		
	}

}
