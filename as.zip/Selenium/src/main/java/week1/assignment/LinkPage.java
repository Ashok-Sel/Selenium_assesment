package week1.assignment;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinkPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
ChromeDriver driver = new ChromeDriver();

driver.navigate().to("http://leafground.com/pages/Link.html");

//Finding where supposed to go without clicking

/*String attribute = driver.findElementByLinkText("Find where am supposed to go without clicking me?").getAttribute("href");
	System.out.println("The Link is " +attribute);
	
	//Broken link
	  
	driver.findElementByLinkText("Verify am I broken?").click();
	System.out.println(driver.getTitle());
	if(driver.getTitle().contains("HTTP Status 404 � Not Found"))	
	{
		System.out.println("The given link is broken");
	}
	
	else 
		System.out.println("The given is not broken");*/
	
    //Go to home page interacting with same link
	driver.findElementByLinkText("Go to Home Page").click();
	driver.findElementByXPath("//h5[contains(text(),'HyperLink')]").click();
	
	//Number of links available in webpage
	List<WebElement> Element= driver.findElementsByXPath("//a");
	System.out.println(Element.size());
	
	for(int i=0;i<	Element.size();i++)
	{
		System.out.println(Element.get(i).getText());
	}
	
	driver.findElementByPartialLinkText("Go to Hom").click();
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("closed");
	driver.close();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
	}

}
