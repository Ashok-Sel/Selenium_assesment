package week1.day1;

public class Mobile {

	public void dialCaller()
	{
		System.out.println("Caller name");
	}
		public boolean sendSms()
	{
		return true;
	}

	int batteryPercentage = 60;
    String model="samsung";
	
    public static void main(String[] args) {
		Mobile o= new Mobile();
		
		o.dialCaller();
		boolean sendSms = o.sendSms();
		
		System.out.println(sendSms);
		int batteryPercentage2 = o.batteryPercentage;
		System.out.println(batteryPercentage2);
		
		String model2 = o.model;
		
		System.out.println(model2);
		
	}
	
	}


