package selenium.ninentydays;

public class May12_Occurance2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="no of o in the given string";
	System.out.println(s.replaceAll("[^o]", "").length());
		
		

	}

}
