package selenium.ninentydays;

import org.testng.annotations.Test;

public class May13_CharType {
	
	int lowerCaseCount=0;
	int upperCaseCount=0;
	int spaceCount=0;
	int numberCount=0;
	
	
	@Test
	public void charType()
	{
		
		String s="It is WorK from home not WoRk for HOme";
		char[] charArray = s.toCharArray();
		for(int i=0;i<charArray.length;i++)
		{
			if(Character.isLowerCase(charArray[i]))
			{
				lowerCaseCount++;
			}
			else if(Character.isUpperCase(charArray[i]))
			{
				upperCaseCount++;
			}
			else if(Character.isDigit(charArray[i]))
			{
				
				numberCount++;
			}
			else if(Character.isWhitespace(charArray[i]))
			{
				spaceCount++;
			}
			else
			{
				System.out.println("Given is a special character "+charArray[i]);
			}
		}
		System.out.println("lower  "+lowerCaseCount+" "+"Upper "+upperCaseCount+" "+"space "+spaceCount+" "+"number "+numberCount);
	}

	
	
	@Test
	public void charType1()
	{
		String s="dfhhR45";
		int i=1;
	
	}
	
}
