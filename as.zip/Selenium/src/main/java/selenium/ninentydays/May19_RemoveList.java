package selenium.ninentydays;

import java.util.ArrayList;
import java.util.List;

public class May19_RemoveList {

	public static void main(String[] args) {
		List<String> lst=new ArrayList<String>();
		lst.add("A");
		lst.add("B");
		lst.add("C");
		lst.add("D");
		lst.add("A");
		lst.add("D");
		lst.add("E");
		lst.add("F");
		List<String> lst1=new ArrayList<String>();
		System.out.println(lst);
		
		for(String e:lst)
		{
			
			if(!lst1.contains(e))
			{
				lst1.add(e);
			}
		}
		System.out.println(lst1);

	}

}
