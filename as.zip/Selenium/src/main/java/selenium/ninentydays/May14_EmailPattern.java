package selenium.ninentydays;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class May14_EmailPattern {

	public static void main(String[] args) {
		
		
		String email="babu.c@tunatap.co.in";
		String pattn="[a-z._]+@[a-z]+.[a-z]{2}+.[a-z]{2}";
		Pattern compile=Pattern.compile(pattn);
		Matcher matcher = compile.matcher(email);
		System.out.println(matcher.matches());
		
		

	}

}
