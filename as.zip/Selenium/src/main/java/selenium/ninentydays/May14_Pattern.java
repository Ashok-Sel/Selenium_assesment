package selenium.ninentydays;

import java.util.regex.Pattern;

public class May14_Pattern {

	public static void main(String[] args) {
		String s="Balaji_1";
		String pat="[a-zA-z0-9_]{8}";
		System.out.println(Pattern.compile(pat).matcher(s).matches());
		

	}

}
