package selenium.ninentydays;

import org.testng.annotations.Test;

public class May13_addition {

	@Test
	public void addNum()
	{
		// TODO Auto-generated method stub
String s= "asdf1qwer9as8d7";
String w=s.replaceAll("[^0-9]", "");
char[] charArray = w.toCharArray();
int add=0;
for(int i=0;i<w.length();i++)
{
	add+=Character.getNumericValue(charArray[i]);
}

System.out.println(add);
	}

@Test
public void addNum1()
{
	// TODO Auto-generated method stub
String s= "asdf1qwer9as8d7";
char[] charArray2 = s.toCharArray();
int add=0;
for(int i=0;i<charArray2.length;i++)
{
	if((int)charArray2[i]>=48 && (int)charArray2[i]<=57)
	{
		add+=Character.getNumericValue(charArray2[i]);
	}
	
	
}
System.out.println("2nd test "+add);
	}


@Test
public void addNum3()
{
	String s="asdf1qwer9as8d7";
	String replaceAll = s.replaceAll("[^0-9]", "");
	System.out.println(replaceAll);
	int add=0;
	int parseInt = Integer.parseInt(replaceAll);
	while(parseInt>0)
	{
		
		int rem=parseInt%10;
		add+=rem;
		parseInt=parseInt/10;
	}
	System.out.println("3rd"+add);
}

}
