/*package selenium.ninentydays;

import java.util.LinkedHashSet;
import java.util.Set;

public class May19_RetriveFromSet {

	public static void main(String[] args) {
	
		Set<String> set1=new LinkedHashSet<>();
		set1.add("1");
		set1.add("2");
		set1.add("3");
		set1.add("4");
		set1.add("5");
		set1.add("6");
		set1.add("7");
		set1.add("8");
		set1.add("9");
		
		for(String e:set1)
		{
			if(e=="7")
			{
				System.out.println(e);
			}
		}
		

	}

}
*/


package selenium.ninentydays;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class May19_RetriveFromSet {

	public static void main(String[] args) {
	
		Set<String> set1=new LinkedHashSet<>();
		set1.add("1");
		set1.add("2");
		set1.add("3");
		set1.add("4");
		set1.add("5");
		set1.add("6");
		set1.add("7");
		set1.add("8");
		set1.add("9");
		
		List<String> lst=new ArrayList<String>();
		lst.addAll(set1);
		
		System.out.println(lst.get(6));
		
		

	}

}
