package selenium.ninentydays;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class May21_map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="Karma";
		char[] charArray = s.toCharArray();
		Map<String,Integer> map=new LinkedHashMap();
		map.put("k",1);
		map.put("a",3);
		map.put("r",2);
		map.put("m",1);
		map.put("i",1);
		map.put("s",1);
		map.put("p",1);
		map.put("k", 10);
		
			Map<String,Integer> map1=new LinkedHashMap<String,Integer>();	
				
				map.entrySet();
				
	
				 for(Entry<String,Integer> e:map.entrySet())
				 {
					
					
			 	}
				 map1.putAll(map);
					
					System.out.println(map.putIfAbsent("o", 2));
					System.out.println(map);
					
					
					
					



	}}
