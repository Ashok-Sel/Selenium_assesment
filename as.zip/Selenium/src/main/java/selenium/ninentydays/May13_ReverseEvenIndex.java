package selenium.ninentydays;

import org.testng.annotations.Test;

public class May13_ReverseEvenIndex {
    @Test
	public void  reverse()
	{
		
		String s="When the world realizes its own mistake";
		String[] split = s.split(" ");
		StringBuffer[] stb=new StringBuffer[4];
		//StringBuffer r=new StringBuffer();
		String rev=" ";
		String fina=" ";
		String add=" ";
		
		int len = split.length;
		
		for(int i=0;i<len;i++)
		{
			if(i%2!=0)
			{
				StringBuffer r=new StringBuffer(split[i]);
				 rev=rev+ r.reverse().toString()+" ";
				 
				 
			
			
			}
			
			else
			{
				rev=rev+split[i]+" ";
			}
			
			
			
			
		}
		System.out.println(rev);
	
		
		
	}
}
