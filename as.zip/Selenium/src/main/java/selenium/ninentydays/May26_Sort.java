package selenium.ninentydays;

import java.util.Arrays;
import java.util.Collections;

public class May26_Sort {

	public static void main(String[] args) {
		Integer[] arr=new Integer[]{5,1,33,79,22,11,45};
       
		
		Arrays.sort(arr);
	    for(int i=0;i<arr.length;i++)
	    {
	    	System.out.print(arr[i]+" ");
	    }
	    System.out.println("");
	    for(int j=arr.length-1;j>=0;j--)
	    {
	    	System.out.print(arr[j]+" ");
	    }
	    
		
	}

}
