package selenium.ninentydays;

import java.util.HashMap;
import java.util.Map;

public class May20_Map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<String,Integer> test=new HashMap<String,Integer>();
		test.put("A", 1);
		test.put("B", 2);
		test.put("C", 3);
		test.put("D", 4);
		test.put("E", 5);
		for(Map.Entry<String, Integer> e:test.entrySet())
		{
		System.out.println(e.getKey()+"->"+e.getValue());
		}
			

	}

}
