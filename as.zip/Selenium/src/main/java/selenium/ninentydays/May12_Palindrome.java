package selenium.ninentydays;

public class May12_Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="malayalam";
		StringBuffer v=new StringBuffer(s);
		int len=s.length();
		String k=v.toString();
		System.out.println(s.equals(k)?"given string is a palindrome":"not a plaindrome");
		
	
	}
	
		

}
