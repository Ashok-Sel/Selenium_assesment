package week4.day1;

import org.openqa.selenium.chrome.ChromeDriver;

public class Iframe {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
ChromeDriver driver=new ChromeDriver();
driver.navigate().to("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
Thread.sleep(5000);
driver.switchTo().frame("iframeResult");
driver.findElementByXPath("//button[text()='Try it']").click();
driver.switchTo().alert().sendKeys("ashok");
driver.switchTo().alert().accept();
driver.findElementByXPath("//p[@id='demo']").getText().contains("ashok");
System.out.println("Verified");
driver.switchTo().defaultContent();
driver.findElementByXPath("//a[@id='tryhome']").click();

	}

}
