package week4.assignment;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Erail {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("https://erail.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		 WebElement sort=driver.findElementByXPath("//input[@title='View trains running on select date']");
			if(sort.isSelected())
			{
				sort.click();
			}
		WebElement source=driver.findElementByXPath("//input[@title='Type SOURCE station code or name']");
		if(source.isEnabled())
		{
			source.clear();
			source.sendKeys("Che");
		}
		//Thread.sleep(3000);
		List<WebElement> stations=driver.findElementsByXPath("//div[starts-with(@title,'Che')]");
		//System.out.println(stations.size());
		for (WebElement e:stations)
		{
			//System.out.println(e.getText());
			if(e.getText().contains("Chembur"))
			{
				e.click();
				
			}
			continue;
			
		}
		WebElement source1	=driver.findElementByXPath("//input[@title='Enter DESTINATION station code or name']");
		if(source1.isEnabled())
		{
			source1.clear();
			source1.sendKeys("mum");
		}
		List<WebElement> stations1=driver.findElementsByXPath("//div[starts-with(@title,'Mum')]");
		//System.out.println(stations1.size());
		for (WebElement e1:stations1)
		{
			
			//System.out.println(e1.getText());
			if(e1.getText().contains("Mumbai Cst"))
			{
				e1.click();
			}
			
		}
		Thread.sleep(3000);
		List<WebElement> train=driver.findElementsByXPath("//table[@class='DataTable TrainList TrainListHeader']/tbody/tr/td[2]");
		System.out.println(train.size());
		Set<WebElement> trains=new LinkedHashSet<WebElement>(train);
		System.out.println(trains.size());
		for(WebElement s:trains)
		{
			System.out.println(s.getText());
		}
		

	}

}
