package week4.assignment;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class JquerySet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
ChromeDriver driver = new ChromeDriver();
driver.navigate().to("https://jqueryui.com/sortable/");
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
driver.manage().window().maximize();
//driver.switchTo().frame("demo-frame");
WebElement item1 = driver.findElementByXPath("//ul/li[@class='ui-state-default ui-sortable-handle'][1]");
WebElement item2 = driver.findElementByXPath("//li[@class='ui-state-default ui-sortable-handle'][2]");
WebElement item3 = driver.findElementByXPath("//li[@class='ui-state-default ui-sortable-handle'][3]");
WebElement item4 = driver.findElementByXPath("//li[@class='ui-state-default ui-sortable-handle'][4]");
Actions move=new Actions(driver);
move.dragAndDrop(item1,item4).perform();;
//move.dragAndDrop(source, target)

	
	
	
	
	}

}
