package week4.assignment;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitToAppear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/home.html");
		driver.findElementByXPath("//h5[text()='Wait to Appear']").click();
		
		WebDriverWait wait=new WebDriverWait(driver,20);	
		wait.until(ExpectedConditions.textToBePresentInElement(driver.findElementById("btn"), "Voila! I'm here Guys"));
		String text = driver.findElementById("btn").getText();
		System.out.println(text);
	}

}
