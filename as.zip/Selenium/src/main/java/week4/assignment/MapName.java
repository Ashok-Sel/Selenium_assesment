package week4.assignment;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Ashoks";
		char[] c=s.toCharArray();
		int len=c.length;
		int count=0;
		Map<Character,Integer> obj=new LinkedHashMap<Character,Integer>();
				for(int i=0;i<len;i++)
				{
					for(int j=0;j<len;j++)
					{
						
					if(obj.containsKey(c[i]))
					{
						obj.put(c[i], 1);
						count++;
					}
					
				    
				
			
				}	
					
					
				}	
				System.out.println(obj);
						
					      
					  
					
				

	}

}
