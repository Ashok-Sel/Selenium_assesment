package week4.assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverWaits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/home.html");
		driver.findElementByXPath("//h5[text()='Wait to Disappear']").click();
		
		WebDriverWait wait = new WebDriverWait (driver, 30);
		WebElement findElementByXPath = driver.findElementByXPath("//strong[contains(text(),'I know you can do it')]");
		String text=findElementByXPath.getText();
		System.out.println(text);
		
		wait.until(ExpectedConditions.textToBePresentInElement(findElementByXPath, text));
		System.out.println("disappear");
	}

}

