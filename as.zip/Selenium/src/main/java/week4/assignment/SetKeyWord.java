package week4.assignment;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetKeyWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="PayPal India";
		char[] strc=str.toCharArray();
		int len=strc.length;
		Set<Character> charSet=new LinkedHashSet<Character>();
		Set<Character> duplCharSet=new LinkedHashSet<Character>();
		for(char c:strc)
		{
			if(charSet.contains(c))
			{
				duplCharSet.add(c);
			}
			System.out.println("Each"+c);
			charSet.add(c);
		}
		
		System.out.println(duplCharSet);
		System.out.println(charSet);
		
		for(char f:duplCharSet)
		{
			
			if(charSet.contains(f))
			{
				charSet.remove(f);
			}
		}
		
		System.out.println(charSet);
		for(char s:charSet)
		{
			if(s!=' ')
			{
				System.out.print(s);
				
			}
			
		}
		
	}

}
