package week4.assignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class ReverseTreeMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] n= {100,200,300};
		String[] s= {"Hari","log"};
Map<Integer,String> obj=new TreeMap<Integer,String>(Collections.reverseOrder());
obj.put(100, "Hari");
obj.put(101, "Naveen");
obj.put(102, "Sam");
obj.put(104, "Balaji");

System.out.println(obj);
//Map<Integer,String> gj=obj.

//Map<Integer,String> i=new TreeMap<Integer,String>;


//System.out.println(l);

for(Map.Entry<Integer,String> e:obj.entrySet())
{
	System.out.println(e.getKey()+"   "+e.getValue());
}


	}

}
	 	
	
	


