package week4.assignment;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class ErailWindows {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
ChromeDriver driver=new ChromeDriver();
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
driver.manage().window().maximize();
driver.navigate().to("https://www.irctc.co.in/nget/train-search");
driver.findElementByXPath("(//button[@type='submit'])[1]").click();
driver.findElementByXPath("//span[text()='AGENT LOGIN']").click();
driver.findElementByXPath("//a[text()='Contact Us']").click();
Set<String> windowHandles = driver.getWindowHandles();
List<String> window = new ArrayList<String>(windowHandles);
String s=window.get(1);
driver.switchTo().window(s);
String text = driver.findElementByXPath("(//p)[2]").getText().replaceAll("[a-zA-Z.]", "");
System.out.println(text);
driver.close();
String f=window.get(0);
driver.switchTo().window(f);
driver.findElementsByXPath("//a[text()='Home']");
driver.close();
	}

}
