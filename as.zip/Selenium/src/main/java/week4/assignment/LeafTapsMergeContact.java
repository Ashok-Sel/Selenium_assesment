package week4.assignment;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class LeafTapsMergeContact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("//input[@name='USERNAME']").sendKeys("DemoCSR");
		driver.findElementByXPath("//input[@name='PASSWORD']").sendKeys("crmsfa");;
		driver.findElementByXPath("//input[@type='submit']").click();
		driver.findElementByXPath("//a[contains(text(),'CRM/SFA')]").click();
		driver.findElementByXPath("//a[text()='Contacts']").click();
		driver.findElementByXPath("//a[text()='Merge Contacts']").click();
		driver.findElementByXPath("//span[text()='From Contact']/..//following-sibling::td/a").click();
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> windows=new ArrayList<String>(windowHandles);
		String  f=windows.get(1);
		driver.switchTo().window(f);
		driver.findElementByXPath("((//table)[4]//td[1])[1]/div/a").click();
		String g=windows.get(0);
		driver.switchTo().window(g);
		driver.findElementByXPath("//span[text()='To Contact']/..//following-sibling::td/a").click();
		Set<String> windowHandles1 = driver.getWindowHandles();
		List<String> windows1=new ArrayList<String>(windowHandles1);
		String  k=windows1.get(1);
		driver.switchTo().window(k);
		driver.findElementByXPath("((//table)[4]//td[1])[1]/div/a").click();
		String l=windows1.get(0);
		driver.switchTo().window(l);
		driver.findElementByXPath("//a[text()='Merge']").click();
		driver.switchTo().alert().accept();
		String title = driver.getTitle();
		System.out.println(title);
		driver.close();
		
		
		
		
		

	}

}
