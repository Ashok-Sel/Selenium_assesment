package week4.assignment;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitUntillChangeToClickMe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/home.html");
		driver.findElementByXPath("//h5[text()='Wait for Text Change']").click();		
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.textToBePresentInElement(driver.findElementById("btn"), "Click ME!"));
		driver.findElementByXPath("//button[text()='Click ME!']").click();
		driver.switchTo().alert().accept();

}
}