package week4.assignment;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Myntra {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		String C="";
		int TotalC=0;
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.navigate().to("https://www.myntra.com/");
		Actions hovr=new Actions(driver);
		WebElement womenTab = driver.findElementByXPath("//header/div[2]/div/following::div/div[2]/div/a[text()='Women']");
		hovr.moveToElement(womenTab).perform();
		driver.findElementByLinkText("Jackets & Coats").click();
		String totalCount = driver.findElementByXPath("//h1[text()='Coats & Jackets For Women']/following::span[1]").getText().replaceAll("[^0-9]", "");
		System.out.println("Total count : "+totalCount);
		int counts=Integer.parseInt(totalCount);
		List<WebElement> count = driver.findElementsByXPath("//span[text()='Categories']/following::ul[@class='categories-list']/li/label/span");
		for(WebElement e:count)
		{
			C=e.getText().replaceAll("[^0-9]", "");
			int parseInt = Integer.parseInt(C);
			TotalC=TotalC+parseInt;
		}
		System.out.println("Total count based on categories :"+TotalC);
		if(counts==TotalC)
		{
			System.out.println("------Total count and Categories are same-----");
			System.out.println("****proceed furthur*****");
			
		}
			
			WebElement coats = driver.findElementByXPath("//label[text()='Coats']/div");
			if(!coats.isSelected())
			{
				coats.click();
				
			}
			
			
			driver.findElementByXPath("//div[@class='brand-more']").click();
			
			driver.findElementByXPath("//input[@placeholder='Search brand']").sendKeys("MANGO");
			driver.findElementByXPath("//label[text()='MANGO']/div").click();
			driver.findElementByXPath("//span[@class='myntraweb-sprite FilterDirectory-close sprites-remove']").click();
			List<WebElement> allBrands = driver.findElementsByXPath("//h3[text()='MANGO']");
			
			for(WebElement e:allBrands)
			{
				if(!e.getText().equals("MANGO"))
				{
					System.out.println(e.getText()+"Not Equals");
				}
				
			
				
			}
			
			System.out.println("EveryThing is Equal ----Please Proceed----");
			
			WebElement sorts = driver.findElementByXPath("//div[@class='sort-sortBy']");
			Actions sort=new Actions(driver);
			sort.moveToElement(sorts).perform();
			//Select sort=new Select(sorts);
			driver.findElementByXPath("//label[text()='Better Discount']").click();
			String price = driver.findElementByXPath("(//span[@class='product-discountedPrice'])[1]").getText().replaceAll("[^0-9]", "");
			System.out.println("Price- "+price);
			WebElement firstItem =driver.findElementByXPath("(//div/h3[@class='product-brand'])[1]");
			sort.moveToElement(firstItem).perform();
			driver.findElementByXPath("(//span[@class='product-actionsButton product-wishlist product-prelaunchBtn'])[1]").click();
			driver.close();
			
			
		
	}

}
