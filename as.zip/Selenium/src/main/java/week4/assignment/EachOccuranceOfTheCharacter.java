package week4.assignment;

public class EachOccuranceOfTheCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s=new String("Welcome To Selenium Automation").replace(" ", "");
		int z=s.length();
		System.out.println(z);
		String[]  t=s.split("");
		String p="";
		String concat="";
		int count =0;
		int y=0;
		
		for(int i=0;i<s.length();i++)
		{
		if(!p.contains(t[i]))
				{
			p = p.concat(t[i]);
			
				}
		}
		System.out.println(p);
			
		for(int k=0;k<p.length();k++)
		{
			count=0;
			for(int j=0;j<s.length();j++)
			{
				
				if(p.charAt(k)==s.charAt(j))
				{
					count++;
				}
				
			}
			System.out.println("char "+p.charAt(k)+"  repeats "+count +" times");
			
			y=y+count;
			
		}
		System.out.println(y);
	}

}
