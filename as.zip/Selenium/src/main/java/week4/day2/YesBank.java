package week4.day2;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.Select;

public class YesBank {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to("https://www.yesbank.in/business-banking/cards/credit-cards");
		Thread.sleep(3000);
		driver.findElementByXPath("//a[@title='Login']").click();
		driver.findElementByXPath("//input[@value='Get Started > >']").click();
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> windows=new ArrayList<String>(windowHandles);
		String window = windows.get(1);
		driver.switchTo().window(window);
		driver.findElementByXPath("//a[text()='Continue to NetBanking']").click();
		driver.findElementByXPath("//strong[text()='Login ID:']/following::input[1]").sendKeys("AishuAshok6");
		driver.findElementByXPath("//strong[text()='Password:']/following::input[1]").sendKeys("Aishu17415@");
		//File src = driver.findElementByXPath("(//img[@alt='Login'])[1]").getScreenshotAs(OutputType.FILE);
		//String path = System.getProperty("user.dir")+"/Screenshot/captcha.png";
		//FileHandler.copy(src, new File(path));
		//ITesseract image=new Tesseract();
		String captcha =JOptionPane.showInputDialog("plz provide");
		Thread.sleep(5000);
		driver.findElementByXPath("//strong[text()='Captcha:']/following::input[1]").sendKeys(captcha);
		driver.findElementByXPath("(//img[@alt='Login'])[2]").click();
		Thread.sleep(3000);
		
		WebElement findElementByXPath = driver.findElementByXPath("//frame[@name='main']");
		driver.switchTo().frame(findElementByXPath);
		
		driver.findElementByXPath("//table/following::tr[@class='AlterRow1']/td/input").click();
		driver.findElementByXPath("//img[@alt='submit']").click();
		
		
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		Set<String> windowHandles1 = driver.getWindowHandles();
		List<String> windows1=new ArrayList<String>(windowHandles1);
		String window1 = windows1.get(0);
		String window2 = windows1.get(1);
		System.out.println(window1);
		System.out.println(window2);
		
		driver.switchTo().window(window2);
		WebElement findElementByXPath2= driver.findElementByXPath("//frame[@name='main']");
		driver.switchTo().frame(findElementByXPath2);
		//WebElement findElementByXPath2 = driver.findElementByXPath("//frame[@name='main']");
		//driver.switchTo().frame(1);
		//driver.switchTo().frame(2);
		//driver.switchTo().frame("main");
		driver.findElementByXPath("//table/tbody/tr/td/following::input[@id='fldPaymentOption2']").click();
		driver.findElementByXPath("//img[@alt='payment']").click();
		
		Thread.sleep(3000);
		
		Set<String> windowHandles2 = driver.getWindowHandles();
		//System.out.println(windowHandles2.size());
		List<String> windows2=new ArrayList<String>(windowHandles2);
		String window3 = windows2.get(2);
		driver.switchTo().window(window3);
		driver.findElementByXPath("(//a)[3]").click();
		driver.findElementByXPath("//input[@value='Pay now']").click();
		
		driver.findElementByXPath("//label[text()='YES BANK Credit Card No.']/following::input[1]").sendKeys("5318");
		driver.findElementByXPath("//label[text()='YES BANK Credit Card No.']/following::input[2]").sendKeys("4910");
		driver.findElementByXPath("//label[text()='YES BANK Credit Card No.']/following::input[3]").sendKeys("2383");
		driver.findElementByXPath("//label[text()='YES BANK Credit Card No.']/following::input[4]").sendKeys("9720");
		driver.findElementByXPath("//label[text()='Re-enter YES BANK Credit Card No.']/following::input[1]").sendKeys("5318");
		driver.findElementByXPath("//label[text()='Re-enter YES BANK Credit Card No.']/following::input[2]").sendKeys("4910");
		driver.findElementByXPath("//label[text()='Re-enter YES BANK Credit Card No.']/following::input[3]").sendKeys("2383");
		driver.findElementByXPath("//label[text()='Re-enter YES BANK Credit Card No.']/following::input[4]").sendKeys("9720");
		driver.findElementByXPath("//label[text()='Mobile Number']/following::input[1]").sendKeys("9941171167");
		driver.findElementByXPath("//label[text()='Email ID']/following::input[1]").sendKeys("ashok061093@gmail.com");
		driver.findElementByXPath("//label[text()='Payment Amount (Rs.) ']/following::input[1]").sendKeys("918");
		WebElement findElementByXPath3 = driver.findElementByXPath("//label[text()='Pay from ']/following::select");
		Select dropDown=new Select(findElementByXPath3);
		dropDown.selectByVisibleText("ICICI Bank");
		driver.findElementByXPath("//input[@value='Pay Now']").click();
		
		
		
		
		
		
		
		
		
		
		
		
		
				

	}

}
