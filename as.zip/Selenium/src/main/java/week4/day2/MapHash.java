package week4.day2;

import java.util.HashMap;
import java.util.Map;

public class MapHash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s ="Good To Go";
		char[] f=s.toCharArray();
		int len=f.length;
		int count=0;
		Map<Character,Integer> obj=new HashMap<Character,Integer>();
		for(int i=0;i<len;i++)
		{
			count=0;
			for(int j=0;j<len;j++)
			{
				if(f[i]==f[j])
				{
					count++;
				}
				
			}
			obj.put(f[i], count);
			
		}
System.out.println(obj);
		
	}

}
