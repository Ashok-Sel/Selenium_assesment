package week5.day1;

import org.openqa.selenium.chrome.ChromeDriver;

public class DeletedLead {

	public static void main(String[] args) throws InterruptedException {
		

				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				ChromeDriver driver = new ChromeDriver();
				driver.navigate().to("http://leaftaps.com/opentaps/control/main");
				driver.findElementByXPath("//input[@name='USERNAME']").sendKeys("DemoCSR");
				driver.findElementByXPath("//input[@name='PASSWORD']").sendKeys("crmsfa");;
				driver.findElementByXPath("//input[@type='submit']").click();
				driver.findElementByXPath("//a[contains(text(),'CRM/SFA')]").click();
				driver.findElementByXPath("//a[contains(text(),'Leads')]").click();
				driver.findElementByXPath("//a[contains(text(),'Find Leads')]").click();
				driver.findElementByXPath("//span[text()='Phone']").click();
				driver.findElementByXPath("//input[@name='phoneNumber']").sendKeys("123456790");
				driver.findElementByXPath("//button[text()='Find Leads']").click();
				Thread.sleep(5000);
				String LeadId = driver.findElementByXPath("(//div/a)[40]").getText();
				System.out.println(LeadId);
				driver.findElementByXPath("(//div/a)[40]").click();
				driver.findElementByXPath("//a[text()='Delete']").click();
				driver.findElementByXPath("//a[contains(text(),'Find Leads')]").click();
				driver.findElementByXPath("//label[text()='Lead ID:']/following::input[1]").sendKeys(LeadId);
				driver.findElementByXPath("//button[text()='Find Leads']").click();
				System.out.println(driver.findElementByXPath("(//table//following-sibling::div)[6]").getText());
				if(driver.findElementByXPath("(//table//following-sibling::div)[6]").getText().contains("No records to display"))
				{
					System.out.println("Deleted succesfully");
				}
				else
				{
					System.out.println("Not Deleted");
				}
					

		// TODO Auto-generated method stub

	}

}
