package personal2;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

public class specific {

	
	
	/*public specific(int a)
	{
		System.out.println("i am a constructor");
	}*/
	
	public static int a=5;
		public int add()
		{
			
			int b=10;
			int c=a+b;
			System.out.println(c);
			return c;
		}
	
	
}