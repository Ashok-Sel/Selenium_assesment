package personal2;



public abstract class point2 {

	public abstract void fddf();
	public abstract void gh();

	
}
