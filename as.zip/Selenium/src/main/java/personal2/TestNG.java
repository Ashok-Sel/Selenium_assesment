package personal2;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNG extends specific {

	
public void main4() {
	
{
	
	specific rt=new specific();

	rt.add();
	int r=add();
	//add();

	
}}
}
