package personal2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class Epass {

	public static void main(String[] args) throws FileNotFoundException, IOException, InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		RemoteWebDriver driver=new ChromeDriver();
		driver.navigate().to("https://tnepass.tnega.org/#/user/pass");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		Properties prop=new Properties();
		prop.load(new FileInputStream(new File("./Project.properties")));
		String property = prop.getProperty("mobile");
		System.out.println(property);
		driver.findElementByXPath("//input[@name='MobileNumber']").sendKeys(prop.getProperty("mobile"));
		String captcha =JOptionPane.showInputDialog("plz provide");
		driver.findElementByXPath("//input[@name='captcha']").sendKeys(captcha);
		driver.findElementByXPath("//button[text()='Send OTP']").click();
		String OTP =JOptionPane.showInputDialog("plz provide");
		driver.findElementByXPath("//input[@name='OTP']").sendKeys(OTP);
		Thread.sleep(10000);
		driver.findElementByXPath("//span[text()='LOGIN']").click();
		Thread.sleep(5000);
		driver.findElementByXPath("//div//h6[text()='Individual/Group Travel via Road ']").click();
	    Thread.sleep(5000);
		try {
		WebElement findElementByXPath = driver.findElementByXPath("//div[@class='modal-content']//div[@class='modal-footer']//button");
		((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+findElementByXPath.getLocation().x+")");
		findElementByXPath.click();
		}
		catch(Exception e)
		{
			System.out.println("Not appear "+e);
		}
		driver.findElementByXPath("(//div[@class='css-16pqwjk-indicatorContainer react-select__indicator react-select__dropdown-indicator'])[1]").click();
		driver.findElementByXPath("//div[text()='Medical Emergency']").click();
		driver.findElementByXPath("//*[@id=\"app-container\"]/main/div/div/div[2]/div/div/div/div[1]/div/div/form/div[1]/div[2]/div/div/div/div[2]/div").click();
		driver.findElementByXPath("//div[text()='Outside District']").click();
		driver.findElementByXPath("//input[@name='ValidFrom']").sendKeys(prop.getProperty("fromdate"));
		driver.findElementByXPath("//input[@name='ValidFrom']").sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		driver.findElementByXPath("//input[@name='ValidTo']").sendKeys(prop.getProperty("todate"));
		driver.findElementByXPath("//input[@name='ValidTo']").sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		driver.findElementByXPath("//input[@name='Name']").sendKeys(prop.getProperty("Name"));
		Thread.sleep(3000);
		
		WebElement Gender =driver.findElementByXPath("//*[@id=\"app-container\"]/main/div/div/div[2]/div/div/div/div[1]/div/div/form/div[2]/div/div/div[2]/div[2]/div/div/div/div[2]/div"); 
		((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+Gender.getLocation().y+")");
		Gender.click();
		System.out.println("fdfsfff");
		String AGender=prop.getProperty("AGender");
		driver.findElementByXPath("//div[text()='"+AGender+"']").click();
		driver.findElementByXPath("//input[@name='FathersName']").sendKeys(prop.getProperty("FatherName"));
        driver.findElementByXPath("//input[@name='Age']").sendKeys(prop.getProperty("Age"));
        driver.findElementByXPath("//input[@name='PeopleCount']").sendKeys(prop.getProperty("PeopleCount"));
        driver.findElementByXPath("//*[@id=\"app-container\"]/main/div/div/div[2]/div/div/div/div[1]/div/div/form/div[2]/div/div/div[3]/div[4]/div/div/div/div[2]/div").click();
        driver.findElementByXPath("//div[text()='Aadhar Card']").click();
        driver.findElementByXPath("//input[@name='ProofID']").sendKeys(prop.getProperty("AadharNumber"));
        WebElement location = driver.findElementByXPath("//input[@type='file']");
        location.sendKeys(prop.getProperty("docLocation"));
        
        //JavascriptExecutor js = (JavascriptExecutor)driver;
       // Actions dropdown = new Actions(driver);
        WebElement vechile = driver.findElementByXPath("(//div[@class='css-16pqwjk-indicatorContainer react-select__indicator react-select__dropdown-indicator'])[5]");
        //dropdown.moveToElement(vechile).click().build().perform();
        
       // js.executeScript("arguments[0].click();", vechile);
        //vechile.click();
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+vechile.getLocation().x+")");
        vechile.click();
        Thread.sleep(2000);
        
        driver.findElementByXPath("//div[contains(text(),'Car/Hired Taxi (Max : Driver + 3 )')]").click();
        driver.findElementByXPath("//input[@name='VehicleNumber']").sendKeys(prop.getProperty("vechilenum"));
        WebElement nextButton = driver.findElementByXPath("//button[text()='Next']");
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+nextButton.getLocation().x+")");
        nextButton.click();
        
        driver.findElementByXPath("//input[@name='FromAddress']").sendKeys(prop.getProperty("AddressL1"));
        driver.findElementByXPath("//input[@name='FromAddress2']").sendKeys(prop.getProperty("AddressL2"));
        driver.findElementByXPath("//input[@name='FromAddress3']").sendKeys(prop.getProperty("AddressL3"));
        
        WebElement district = driver.findElementByXPath("//*[@id=\"app-container\"]/main/div/div/div[2]/div/div/div/div[1]/div/div/form/div/div[1]/div[6]/div/div/div/div/div[2]/div");
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+district.getLocation().x+")");
        district.click();
        String locations=prop.getProperty("fromdistrict");
        driver.findElementByXPath("//div[text()='"+locations+"']").click();
        
        WebElement taluk = driver.findElementByXPath("//*[@id=\"app-container\"]/main/div/div/div[2]/div/div/div/div[1]/div/div/form/div/div[1]/div[7]/div/div/div/div/div[2]/div");
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+taluk.getLocation().x+")");
        taluk.click();
        String taluks=prop.getProperty("fromTaluk");
        driver.findElementByXPath("//div[text()='"+taluks+"']").click();
        driver.findElementByXPath("//input[@name='FromPinCode']").sendKeys(prop.getProperty("pinCode"));
        
        driver.findElementByXPath("//input[@name='ToAddress']").sendKeys(prop.getProperty("ToAddressL1"));
        driver.findElementByXPath("//input[@name='ToAddress2']").sendKeys(prop.getProperty("ToAddressL2"));
        driver.findElementByXPath("//input[@name='ToAddress3']").sendKeys(prop.getProperty("ToAddressL3"));
        WebElement toDistict = driver.findElementByXPath("//*[@id=\"app-container\"]/main/div/div/div[2]/div/div/div/div[1]/div/div/form/div/div[2]/div[6]/div/div/div/div/div[2]/div");
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+toDistict.getLocation().x+")");
        toDistict.click();
        String toDistrict=prop.getProperty("toDistrict");
        driver.findElementByXPath("//div[text()='"+toDistrict+"']").click();
        WebElement toTaluk = driver.findElementByXPath("//*[@id=\"app-container\"]/main/div/div/div[2]/div/div/div/div[1]/div/div/form/div/div[2]/div[7]/div/div/div/div/div[2]/div");
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+toTaluk.getLocation().x+")");
        toTaluk.click();
        String toTaluks=prop.getProperty("toTaluk");
        driver.findElementByXPath("//div[text()='"+toTaluks+"']").click();
        driver.findElementByXPath("//input[@name='ToPinCode']").sendKeys(prop.getProperty("toPincode"));
        
        driver.findElementByXPath("//button[text()='Next']").click();
        
        Thread.sleep(5000);
        WebElement location1 = driver.findElementByXPath("//input[@type='file']");
        location1.sendKeys(prop.getProperty("docLocation"));
        driver.findElementByXPath("//span[text()='Add Passenger ']").click();
        
        driver.findElementByXPath("//input[@name='Name']").sendKeys(prop.getProperty("pName"));
        driver.findElementByXPath("//input[@name='TravellerAge']").sendKeys(prop.getProperty("pAge"));
        WebElement gender = driver.findElementByXPath("//*[@id=\"Overall_Style\"]/div[3]/div/div[1]/div/div/form/div[1]/div[1]/div[3]/div/div/div/div[2]/div");
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+gender.getLocation().x+")");
        gender.click();
        String pGender=prop.getProperty("pGender");
        driver.findElementByXPath("//div[text()='"+pGender+"']").click();
        driver.findElementByXPath("//input[@name='FatherName']").sendKeys(prop.getProperty("pfather"));
        driver.findElementByXPath("//input[@name='AadhaarNumber']").sendKeys(prop.getProperty("pAadhar"));
        WebElement copyAddress = driver.findElementByXPath("//label[text()='Copy Address From']/following::div[6]");
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+copyAddress.getLocation().x+")");
        copyAddress.click();
        driver.findElementByXPath("//div[text()='Applicant']").click();
      
        
        WebElement add = driver.findElementByXPath("//button[text()='Add']");
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+add.getLocation().x+")");
        add.click();
        
        WebElement submit = driver.findElementByXPath("//button[text()='Submit']");
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+submit.getLocation().x+")");
        submit.click();
        
        WebElement yes = driver.findElementByXPath("//button[text()='Yes']");
        ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+yes.getLocation().x+")");
        yes.click();
        
      
		
		

	}

}
