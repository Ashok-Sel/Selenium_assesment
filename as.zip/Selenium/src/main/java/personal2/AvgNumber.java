package personal2;

public class AvgNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] numbers= {1,7,89,66,54,2};
		int size=numbers.length;
		int sum=0;
		float avg=0;
		for(int i=0;i<size;i++)
		{
			sum+=numbers[i];
		}
      avg=sum/size;
      System.out.println(avg);
	}

}
