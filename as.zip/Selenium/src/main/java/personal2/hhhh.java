package personal2;

public abstract class hhhh {

	public abstract void jjh();
}
