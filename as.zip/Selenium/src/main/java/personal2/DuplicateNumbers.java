package personal2;

public class DuplicateNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {22,12,45,67,45,33,2,12,9,5,7,2};
		int[] arr2= {22,12,45,67,45,33,2,12,9,5,7,2};
		int count=0;
		for(int i=0;i<arr.length;i++)
		{
			count=0;
			for(int j=0;j<arr.length;j++)
			{
				
				if(arr[i]==arr[j])
				{
					count++;
				}
				
				
			}
			if(count>=2)
			{
				
				System.out.println("dup num :" +arr[i]);
				
			}
			
			
		}

	}

}
