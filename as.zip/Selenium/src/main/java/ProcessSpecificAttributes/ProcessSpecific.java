package ProcessSpecificAttributes;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import testcase.ReadExcel;


 public class ProcessSpecific extends ReadExcel {

	public static ChromeDriver driver;
	public static String excelFile;
	
		 @BeforeMethod public void details()
		{
			
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("http://leaftaps.com/opentaps/control/login");
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			driver.findElementById("username").sendKeys("DemoCSR");
			driver.findElementById("password").sendKeys("crmsfa");
			driver.findElementByClassName("decorativeSubmit").click();
			driver.findElementByLinkText("CRM/SFA").click();
			
		}
		
		 @BeforeTest
			public void setData() {
				excelFile = "Test001";
			}

	
		@DataProvider
		public String[][]  getDetails() throws IOException
		{
			ReadExcel data1=new ReadExcel();
			return data1.excel(excelFile);

			
			
			
			
			
	}
	

}
