package runners.api;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features= {"./Features/Justdial.feature"},
                  glue="Steps",
                  monochrome=true)
public class JustDialRunner extends AbstractTestNGCucumberTests {

}
