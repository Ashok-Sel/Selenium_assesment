package runners.api;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features= {"./features/Bigbasket.feature"},
                  glue= {"project.pages"},
                  monochrome=true)
public class Runner extends AbstractTestNGCucumberTests  {
@Test
public void tests() {
	System.out.println("testing");
}
}
