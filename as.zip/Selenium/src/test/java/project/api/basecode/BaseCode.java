package project.api.basecode;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import project.api.basedesign.Browser1;
import project.api.basedesign.Project;

public class BaseCode implements Project,Browser1{

	public static RemoteWebDriver driver;
	public static Properties prop;
	public void setDriver(String browser) {

		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			driver= new ChromeDriver(); 
		}
		else
		{
			System.out.println("unknown browser given");
		}
	}

	public void launchUrl(String url) {
		driver.navigate().to(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	public WebElement findElement(String locator, String value) {

		switch(locator.trim().toLowerCase().replaceAll(" ", ""))
		{
		case "id"          :return driver.findElement(By.id(value));          
		case "classname"   :return driver.findElement(By.className("value"));
		case "text"        :return driver.findElement(By.xpath(value));
		case "xpath"       :return driver.findElement(By.xpath(value));
		case "cssSelector" :return driver.findElement(By.cssSelector(value));
		case "linktext"    :return driver.findElement(By.linkText(value));
		case "partiallinktext":return driver.findElement(By.partialLinkText(value));

		}
		return null;

	}

	public void clearAndType(WebElement ele, String input) {
		// TODO Auto-generated method stub
		ele.clear();
		ele.sendKeys(input);
	}

	public void click(WebElement ele) {
		// TODO Auto-generated method stub
		ele.click();
	}

	
	public void alertAccept() {
		driver.switchTo().alert().accept();


	}


	public void alertReject() {
		// TODO Auto-generated method stub
		driver.switchTo().alert().dismiss();
	}


	public void alertSendkeys(String value) {
		driver.switchTo().alert().sendKeys(value);

	}

	public void propertyFile() throws FileNotFoundException, IOException {
		prop = new Properties();
		prop.load(new FileInputStream("./Project.properties"));


	}


	public void unloadPropertyFile() {
		prop=null;

	}

	


	
	public void selectFrameByIndex(int index) {
		driver.switchTo().frame(index);
		
	}

	
	public void selectFrameByName(String nameorid) {
		driver.switchTo().frame(nameorid);
		
	}

	
	public void getTitle() {
	driver.getTitle();
		
	}

	@Override
	public void getAllwindowsByIndex(int index) {
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> w=new ArrayList<String>(windowHandles);
		
		driver.switchTo().window(w.get(index));
		
		
			
	}

	@Override
	public void closeWindow() {
		// TODO Auto-generated method stub
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> w=new ArrayList<String>(windowHandles);
		
		driver.switchTo().window(w.get(1)).close();
		
	}









}
