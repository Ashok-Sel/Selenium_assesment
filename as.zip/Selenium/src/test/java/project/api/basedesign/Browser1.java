package project.api.basedesign;

import org.openqa.selenium.WebElement;

public interface Browser1 {
	
	/*
	 * set the system property
	 * driver object will be created
	 * @author ashok
	 */
	public void setDriver(String driver);
	
	/*
	 * Launch the url
	 * Maximize the page
	 * @param url
	 * Set the implicit wait
	 */
	public void launchUrl(String url);
	
	/*
	 * find the elements
	 * @param locator
	 * @param value
	 */
	
	public WebElement findElement(String locator,String value);
	
	/*
	 * accepting alert
	 */
	public void alertAccept();
	/*
	 * Dismiss alert
	 */
	public void alertReject();
	/*
	 * Alert sendKeys
	 */
	public void alertSendkeys(String value);
	
		
	public void getTitle();
	
	public void getAllwindowsByIndex(int val);
	

}
