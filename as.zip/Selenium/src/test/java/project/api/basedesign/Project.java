package project.api.basedesign;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebElement;

public interface Project {
	
	/*
	 * clear the Element 
	 * type the value in the given element
	 * @param ele
	 * @param input
	 */
	public void clearAndType(WebElement ele,String input);
	
	/*
	 * click on the given element
	 */
	public void click(WebElement ele);
	

	public void propertyFile() throws FileNotFoundException, IOException;
	
	public void unloadPropertyFile();
	
	public void selectFrameByIndex(int k);
	
	public void selectFrameByName(String f);
	
	public void closeWindow();
}
