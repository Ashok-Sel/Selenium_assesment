package project.pages;

import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import project.specificmethod.CommonClass;

public class LoginPage extends CommonClass {

	@And("Login to the application")
	public LoginPage clickLogin()
	{
		System.out.println("inside login page");
	WebElement login=findElement("linktext","Login");
	click(login);
	return this;
	}	
	
	@And("Click Gmail")
	public GmailLoginPage clickGmail() throws InterruptedException
	{
		WebElement gmail=findElement("xpath","//a[@class='gplusBtn smGlobalBtn']");
		Thread.sleep(3000);
		click(gmail);
		System.out.println("gmail button clicked");
		Thread.sleep(3000);
		return new GmailLoginPage();
		
	}
	
	
}
	
