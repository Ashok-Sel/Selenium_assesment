package project.pages;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import cucumber.api.java.Before;
import project.api.basecode.BaseCode;

import project.specificmethod.CommonClass;

public class Hooksk extends CommonClass {
	
	
	
	
   @Before
	public void BeforeMethod1()
	{
		
		setDriver(prop.getProperty("browser"));
		launchUrl(prop.getProperty("url"));
		
	}
	
    @Before
	public void loadProperties() throws FileNotFoundException, IOException
	{
	propertyFile();
	}
}
