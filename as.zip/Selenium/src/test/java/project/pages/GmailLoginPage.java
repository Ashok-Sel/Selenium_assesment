package project.pages;

import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import project.specificmethod.CommonClass;

public class GmailLoginPage extends CommonClass{
	
	@And("Click gmail account")
	public GmailLoginPage clickGmailAccount() throws InterruptedException
	{
		getAllwindowsByIndex(1);
		WebElement findElement = findElement("xpath","//input[@type='email']");
		System.out.println(prop.getProperty("gmail"));
		clearAndType(findElement,prop.getProperty("gmail"));
		Thread.sleep(3000);
		WebElement findElement1 = findElement("xpath","//input[@type='email']");
		Thread.sleep(3000);
		return this;
		
	    
	}
	
	@Then("close the window")
	public GmailLoginPage closeCurrentWindow()
	{
		closeWindow();
		return this;
	}
}
