package project.testcases;

import org.testng.annotations.Test;

import project.pages.LoginPage;
import project.specificmethod.CommonClass;

public class BigBasket extends CommonClass {

	@Test
	public void Start() throws InterruptedException
	{
		new LoginPage()
		.clickLogin()
	    .clickGmail()
		.clickGmailAccount()
		.closeCurrentWindow();
		
		
	}
	
}
