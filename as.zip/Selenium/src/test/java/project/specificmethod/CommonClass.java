package project.specificmethod;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import cucumber.api.java.en.Given;
import project.api.basecode.BaseCode;

public class CommonClass extends BaseCode {
	
	
	
	
     
	
	@BeforeMethod
	public void BeforeMethod1()
	{
		setDriver(prop.getProperty("browser"));
		launchUrl(prop.getProperty("url"));
		
	}
	
	@BeforeSuite
	public void loadProperties() throws FileNotFoundException, IOException
	{
	propertyFile();
	}
	
	@AfterSuite
	public void unLoadProperties()
	{
		unloadPropertyFile();
	}
	
	
}
