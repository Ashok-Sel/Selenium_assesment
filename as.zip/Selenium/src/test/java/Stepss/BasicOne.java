package Stepss;

import org.openqa.selenium.chrome.ChromeDriver;

public class BasicOne {

	public static ChromeDriver driver;
}
