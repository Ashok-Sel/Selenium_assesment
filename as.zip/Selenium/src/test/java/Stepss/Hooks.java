package Stepss;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import cucumber.api.java.Before;
import project.api.basecode.BaseCode;
import project.specificmethod.CommonClass;

public class Hooks extends CommonClass {
	
	
	@Before
	public static ChromeDriver  Setdriver()
	{
	
	 ChromeOptions options=new ChromeOptions();
	 options.addArguments("--disable-notifications");
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		 driver=new ChromeDriver(options);
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		 return (ChromeDriver) driver;
		 
		
	}
	
   
}
