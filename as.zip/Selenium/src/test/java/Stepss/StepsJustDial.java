package Stepss;


import java.util.List;

import org.apache.commons.collections4.bag.SynchronizedSortedBag;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class StepsJustDial extends BasicOne {

	public StepsJustDial()
	{
		this.driver=Hooks.Setdriver();
		
	}
	
	@Given("open the justdial")
	public void open_the_justdial() {
		
	    System.out.println("fgfghh");
		driver.navigate().to("https://www.justdial.com/");
	}
	
	@And("Cick on Air Tickets")
	public void click_on_airTickets()
	{
		driver.findElementByXPath("//span[text()='Air Tickets']").click();
	}
	
	@And ("^Choose the depature as \"([^\"]*)\"$")
	public void chooseFrom(String dep)
	{
		System.out.println(dep);
		String depature=dep;
		if(depature.charAt(0)=='['&&depature.charAt(depature.length()-1)==']')
			depature=depature.substring(1,depature.length()-1);
		
			driver.findElementByXPath("//input[@id='departure']").sendKeys(dep);
			driver.findElementByXPath("//li[text()='Chennai, IN - Chennai Airport (MAA)']").click();
			
	}
	@And("Choose the Going to")
	public void goingTo()
	{
		driver.findElementByXPath("//input[@id='arrival']").sendKeys("Toronto");
		driver.findElementByXPath("//li[text()='Toronto, CA - Toronto City Centre Airport (YTZ)']").click();
	}
    @And("Set depature date")
    public void setDepatureDate()
    {
    	driver.findElementByXPath("//input[@id='departDate']").click();
    	driver.findElementByXPath("//span[text()='Next']").click();
    	driver.findElementByXPath("//a[text()='22']").click();
    	
    }
    @Then("Add adult and children count and search")
    public void adultAndChildrenCount()
    {
    	driver.findElementByXPath("(//span[@class='plus'])[1]").click();
    	WebElement children=driver.findElementByXPath("(//span[@class='plus'])[2]");
    	Actions child=new Actions(driver);
    	child.moveToElement(children).doubleClick().perform();
    	driver.findElementByXPath("//input[@value='SEARCH']").click();
    	
    }
    
    @And("Select the Airline")
    public void SelecttheAirline()
    {
    	driver.findElementByXPath("//input[@value='AC']").click();
    	
    }
    
    @Then("Click on Price to sort the result")
    public void sortPrice()
    {
    	driver.findElementByXPath("//a[@id='priceSort']").click();
    }
    
    @And("Click on the details button")
    public void detailsButton()
    {
    	driver.findElementByXPath("(//a[text()='+ Details'])[1]").click();
    }
    
    @And("Get the Arrival details")
    public void arrivalTime()
    {
    	List<WebElement> arrival=driver.findElementsByXPath("(//tbody)[8]/tr/td[6]");
    	for(WebElement e:arrival)
    	{
    	System.out.println("Arrival time= "+e.getText());
    	}
    }
    
    @And("Capture the total price in a list and Click on Book")
    public void capturePrice()
    {
       String Price = driver.findElementByXPath("//span[text()='Total']/..//div//span").getText();
       System.out.println(Price);
       driver.findElementByXPath("(//a[text()='BOOK'])[1]").click();
       
    }
}
